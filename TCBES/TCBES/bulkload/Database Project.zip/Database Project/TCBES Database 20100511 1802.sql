-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.1.37-1ubuntu5.1


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema TCBES
--

CREATE DATABASE IF NOT EXISTS TCBES;
USE TCBES;

--
-- Definition of table `collection`
--

DROP TABLE IF EXISTS `collection`;
CREATE TABLE `collection` (
  `catalog_code` char(9) NOT NULL,
  `event_code` char(9) NOT NULL,
  `short_scientific_name` char(9) NOT NULL,
  `number_sample` int(10) unsigned DEFAULT NULL,
  `number_male` int(10) unsigned DEFAULT NULL,
  `number_female` int(10) unsigned DEFAULT NULL,
  `collection_note` text,
  PRIMARY KEY (`catalog_code`,`event_code`),
  KEY `specimen_FKIndex1` (`event_code`),
  KEY `collection_FKIndex3` (`short_scientific_name`),
  CONSTRAINT `collection_ibfk_1` FOREIGN KEY (`event_code`) REFERENCES `event` (`event_code`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `collection_ibfk_2` FOREIGN KEY (`short_scientific_name`) REFERENCES `life` (`short_scientific_name`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `collection`
--

/*!40000 ALTER TABLE `collection` DISABLE KEYS */;
INSERT INTO `collection` (`catalog_code`,`event_code`,`short_scientific_name`,`number_sample`,`number_male`,`number_female`,`collection_note`) VALUES 
 ('','','',1,1,0,'1'),
 ('01','m0001','DroDroDip',0,0,0,''),
 ('01','m0002','DroDroDip',0,0,0,''),
 ('01','m0003','DroDroDip',0,0,0,''),
 ('01','m0004','DroDroDip',0,0,0,''),
 ('01','m0005','DroDroDip',0,0,0,''),
 ('01','m0006','DroDroDip',0,0,0,''),
 ('01','m0007','CamDolDip',0,0,0,''),
 ('01','m0008','NesDolDip',0,0,0,''),
 ('01','m0009','DroDroDip',0,0,0,''),
 ('01','m0010','DroDroDip',0,0,0,''),
 ('01','m0011','DroDroDip',0,0,0,''),
 ('01','m0012','DroDroDip',0,0,0,'small, thorax dark'),
 ('01','m0013','LisMusDip',0,0,0,'with remains of Dicranomyia prey (from photo)'),
 ('01','m0014','PsyHem',0,0,0,'on underside of leaf with abundant filamentous wax'),
 ('01','m0015','DroDroDip',0,0,0,''),
 ('01','m0016','DroDroDip',0,0,0,''),
 ('01','m0017','DroDroDip',0,0,0,''),
 ('01','m0018','DroDroDip',0,0,0,''),
 ('01','m0019','S. DroDip',0,0,0,''),
 ('01','m0020','DroDroDip',0,0,0,''),
 ('01','m0021','DroDroDip',0,0,0,''),
 ('01','m0022','DroDroDip',0,0,0,''),
 ('01','m0023','GryOrt',0,0,0,''),
 ('01','m0024','OrtMirHem',0,0,0,''),
 ('01','m0025','NesCicHem',0,0,0,''),
 ('01','m0026','LisMusDip',0,0,0,''),
 ('01','m0027','NitCol',0,0,0,'3 adults, 2 larvae'),
 ('01','m0028','DroDroDip',0,0,0,''),
 ('01','m0029','DroDroDip',0,0,0,''),
 ('01','m0030','NesCicHem',0,0,0,''),
 ('01','m0031','DroDroDip',0,0,0,''),
 ('01','m0032','DroDroDip',0,0,0,'small, wing marks pale'),
 ('01','m0033','NysLygHem',0,0,0,'various instars, no adults; apparently feeding on seeds, most of which were destroyed'),
 ('01','m0034','DroDroDip',0,0,0,''),
 ('01','m0035','DroDroDip',0,0,0,''),
 ('01','m0036','DroDroDip',0,0,0,''),
 ('01','m0037','SieBetHym',0,0,0,''),
 ('01','m0038','DroDroDip',0,0,0,''),
 ('01','m0039','DroDroDip',0,0,0,''),
 ('01','m0040','DroDroDip',0,0,0,''),
 ('01','m0041','DroDroDip',0,0,0,''),
 ('01','m0042','DroDroDip',0,0,0,''),
 ('01','m0043','DroDroDip',0,0,0,''),
 ('01','m0044','NesCicHem',0,0,0,''),
 ('01','m0045','OrtMirHem',0,0,0,''),
 ('01','m0046','DroDroDip',0,0,0,''),
 ('01','m0047','DroDroDip',0,0,0,''),
 ('01','m0048','DroDroDip',0,0,0,''),
 ('01','m0049','DroDroDip',0,0,0,''),
 ('01','m0050','DroDroDip',0,0,0,''),
 ('01','m0051','DroDroDip',0,0,0,''),
 ('01','m0052','NesCicHem',0,0,0,''),
 ('01','m0053','DroDroDip',0,0,0,''),
 ('01','m0054','SieBetHym',0,0,0,''),
 ('01','m0055','ProAglCol',0,0,0,''),
 ('01','m0056','DroDroDip',0,0,0,''),
 ('01','m0057','ArcDolDip',0,0,0,''),
 ('01','m0058','S. DroDip',0,0,0,'male and female look very different!'),
 ('01','m0059','DroDroDip',0,0,0,''),
 ('01','m0060','DroDroDip',0,0,0,''),
 ('01','m0061','DroDroDip',0,0,0,''),
 ('01','m0062','DroDroDip',0,0,0,'wing elongate, R4+5 spot isolated, apex of R2+3 well anterior of apex of M, last section of M twice as long as penultimate section; wing marks somewhat similar to fuscoamoeba group but antenna, ovipositor like picture wings'),
 ('01','m0063','DroDroDip',0,0,0,'wing resembles hemipeza but no extra crossvein; no cilia on legs, front with a clump of long erect bristles on each side'),
 ('01','m0064','DroDroDip',0,0,0,''),
 ('01','m0065','DroDroDip',0,0,0,''),
 ('01','m0066','DroDroDip',0,0,0,''),
 ('01','m0067','DroDroDip',0,0,0,''),
 ('01','m0068','DroDroDip',0,0,0,''),
 ('01','m0069','DroDroDip',0,0,0,''),
 ('01','m0070','DroDroDip',0,0,0,''),
 ('01','m0071','DroDroDip',0,0,0,'one female much larger with yellow tibiae; claytonae?'),
 ('01','m0072','DroDroDip',0,0,0,''),
 ('01','m0073','DroDroDip',0,0,0,''),
 ('01','m0074','DroDroDip',0,0,0,''),
 ('01','m0075','DroDroDip',0,0,0,''),
 ('01','m0076','DroDroDip',0,0,0,''),
 ('01','m0077','DroDroDip',0,0,0,''),
 ('01','m0078','DroDroDip',0,0,0,'may be claytonae; thorax lighter, cilia only cover 2/3 of tibia, legs of females yellow'),
 ('01','m0079','DroDroDip',0,0,0,''),
 ('01','m0080','DroDroDip',0,0,0,''),
 ('01','m0081','DroDroDip',0,0,0,'appears to be all one species'),
 ('01','m0082','DroDroDip',0,0,0,''),
 ('01','m0083','DroDroDip',0,0,0,''),
 ('01','m0084','DroDroDip',0,0,0,''),
 ('01','m0085','DroDroDip',0,0,0,''),
 ('01','m0086','DroDroDip',0,0,0,''),
 ('01','m0087','DroDroDip',0,0,0,''),
 ('01','m0088','DroDroDip',0,0,0,''),
 ('01','m0089','DroDroDip',0,0,0,''),
 ('01','m0090','DroDroDip',0,0,0,''),
 ('01','m0091','SieBetHym',0,0,0,''),
 ('01','m0092','DroDroDip',0,0,0,''),
 ('01','m0093','DroDroDip',0,0,0,''),
 ('01','m0094','DroDroDip',0,0,0,''),
 ('01','m0095','DroDroDip',0,0,0,''),
 ('01','m0096','DroDroDip',0,0,0,''),
 ('01','m0097','DroDroDip',0,0,0,''),
 ('01','m0098','DroDroDip',0,0,0,''),
 ('01','m0099','DroDroDip',0,0,0,''),
 ('01','m0100','DroDroDip',0,0,0,''),
 ('01','m0101','DroDroDip',0,0,0,'paler than sponge specimen, ovipositor yellow as well'),
 ('01','m0102','DroDroDip',0,0,0,''),
 ('01','m0103','DroDroDip',0,0,0,''),
 ('01','m0104','DroDroDip',0,0,0,''),
 ('01','m0105','DroDroDip',0,0,0,''),
 ('01','m0106','S. DroDip',0,0,0,''),
 ('01','m0107','DroDroDip',0,0,0,''),
 ('01','m0108','S. DroDip',0,0,0,''),
 ('01','m0110','DroDroDip',0,0,0,''),
 ('01','m0111','CepPipDip',0,0,0,''),
 ('01','m0112','DroDroDip',0,0,0,''),
 ('01','m0113','DroDroDip',0,0,0,''),
 ('01','m0114','DroDroDip',0,0,0,''),
 ('01','m0115','S. DroDip',0,0,0,''),
 ('01','m0116','DroDroDip',0,0,0,''),
 ('01','m0117','DroDroDip',0,0,0,''),
 ('01','m0118','HylColHym',0,0,0,''),
 ('01','m0119','DroDroDip',0,0,0,''),
 ('01','m0120','DroDroDip',0,0,0,''),
 ('02','m0001','DroDroDip',0,0,0,'anterior leg cilia, yellow'),
 ('02','m0002','DroDroDip',0,0,0,''),
 ('02','m0003','DroDroDip',0,0,0,''),
 ('02','m0004','DroDroDip',0,0,0,''),
 ('02','m0005','DroDroDip',0,0,0,''),
 ('02','m0006','DroDroDip',0,0,0,''),
 ('02','m0007','CamDolDip',0,0,0,''),
 ('02','m0008','NesDolDip',0,0,0,''),
 ('02','m0009','DroDroDip',0,0,0,''),
 ('02','m0010','DroDroDip',0,0,0,''),
 ('02','m0011','DroDroDip',0,0,0,''),
 ('02','m0012','DroDroDip',0,0,0,''),
 ('02','m0015','DroDroDip',0,0,0,''),
 ('02','m0017','DroDroDip',0,0,0,''),
 ('02','m0020','DroDroDip',0,0,0,''),
 ('02','m0022','DroDroDip',0,0,0,'appears to fit description of furcatarsus from Kauai'),
 ('02','m0024','NesCicHem',0,0,0,''),
 ('02','m0028','DroDroDip',0,0,0,''),
 ('02','m0029','DroDroDip',0,0,0,''),
 ('02','m0031','DroDroDip',0,0,0,''),
 ('02','m0032','DroDroDip',0,0,0,''),
 ('02','m0034','DroDroDip',0,0,0,''),
 ('02','m0035','DroDroDip',0,0,0,''),
 ('02','m0036','S. DroDip',0,0,0,''),
 ('02','m0039','DroDroDip',0,0,0,'dark thorax'),
 ('02','m0040','DroDroDip',0,0,0,''),
 ('02','m0041','DroDroDip',0,0,0,''),
 ('02','m0042','DroDroDip',0,0,0,''),
 ('02','m0043','CamDolDip',0,0,0,''),
 ('02','m0047','DroDroDip',0,0,0,''),
 ('02','m0048','DroDroDip',0,0,0,''),
 ('02','m0049','DroDroDip',0,0,0,''),
 ('02','m0050','DroDroDip',0,0,0,''),
 ('02','m0051','DroDroDip',0,0,0,''),
 ('02','m0053','DroDroDip',0,0,0,''),
 ('02','m0056','DroDroDip',0,0,0,'parasitic mite attached to abdomen'),
 ('02','m0058','NesCicHem',0,0,0,''),
 ('02','m0059','DroDroDip',0,0,0,''),
 ('02','m0060','DroDroDip',0,0,0,''),
 ('02','m0061','DroDroDip',0,0,0,''),
 ('02','m0063','DroDroDip',0,0,0,''),
 ('02','m0064','DroDroDip',0,0,0,''),
 ('02','m0065','DroDroDip',0,0,0,''),
 ('02','m0066','DroDroDip',0,0,0,''),
 ('02','m0067','DroDroDip',0,0,0,'pic 1; anepimeron with a dark spot, wing infuscated at apex, legs yellow instead of white, hind tibia not much darker than femur, T6 paler than others, anterior dorsocentral &gt;1/2 as long as posterior'),
 ('02','m0068','DroDroDip',0,0,0,''),
 ('02','m0069','DroDroDip',0,0,0,'putative females have no wing marks'),
 ('02','m0070','DroDroDip',0,0,0,''),
 ('02','m0072','DroDroDip',0,0,0,''),
 ('02','m0073','DroDroDip',0,0,0,''),
 ('02','m0074','DroDroDip',0,0,0,''),
 ('02','m0075','DroDroDip',0,0,0,''),
 ('02','m0076','DroDroDip',0,0,0,''),
 ('02','m0077','DroDroDip',0,0,0,''),
 ('02','m0078','DroDroDip',0,0,0,''),
 ('02','m0080','DroDroDip',0,0,0,''),
 ('02','m0081','DroDroDip',0,0,0,''),
 ('02','m0082','DroDroDip',0,0,0,''),
 ('02','m0083','DroDroDip',0,0,0,''),
 ('02','m0084','NitCol',0,0,0,'very large specimen appears to be endemic, small one alien'),
 ('02','m0085','DroDroDip',0,0,0,'pale legs'),
 ('02','m0086','DroDroDip',0,0,0,''),
 ('02','m0087','S. DroDip',0,0,0,''),
 ('02','m0088','DroDroDip',0,0,0,''),
 ('02','m0089','DroDroDip',0,0,0,''),
 ('02','m0090','NesMirHem',0,0,0,''),
 ('02','m0092','DroDroDip',0,0,0,''),
 ('02','m0093','DroDroDip',0,0,0,''),
 ('02','m0094','DroDroDip',0,0,0,''),
 ('02','m0096','DroDroDip',0,0,0,''),
 ('02','m0097','DroDroDip',0,0,0,''),
 ('02','m0098','DroDroDip',0,0,0,''),
 ('02','m0099','DroDroDip',0,0,0,''),
 ('02','m0100','DroDroDip',0,0,0,'keys to sodomae, with larger basal spot like obatai, cilia only on basitarsus, hind margins of abdominal segments brown'),
 ('02','m0101','DroDroDip',0,0,0,'one is probably kambysellisi'),
 ('02','m0102','DroDroDip',0,0,0,'prominent preapical dorsal bristle, ciliation of tibia extends to base on anterior surface'),
 ('02','m0103','DroDroDip',0,0,0,'pleura entirely yellow, but no extra dorsocentrals'),
 ('02','m0104','DroDroDip',0,0,0,''),
 ('02','m0105','DroDroDip',0,0,0,''),
 ('02','m0107','DroDroDip',0,0,0,''),
 ('02','m0109','DroDroDip',0,0,0,''),
 ('02','m0112','DroDroDip',0,0,0,''),
 ('02','m0113','DroDroDip',0,0,0,''),
 ('02','m0116','DroDroDip',0,0,0,''),
 ('02','m0117','DroDroDip',0,0,0,''),
 ('02','m0119','DroDroDip',0,0,0,''),
 ('03','m0001','DroDroDip',0,0,0,''),
 ('03','m0002','SarMirHem',0,0,0,''),
 ('03','m0003','S. DroDip',0,0,0,''),
 ('03','m0004','DroDroDip',0,0,0,''),
 ('03','m0005','DroDroDip',0,0,0,'black antennae'),
 ('03','m0006','DroDroDip',0,0,0,''),
 ('03','m0009','DroDroDip',0,0,0,''),
 ('03','m0010','DroDroDip',0,0,0,'female: mesonotum all yellow'),
 ('03','m0011','DroDroDip',0,0,0,''),
 ('03','m0012','DroDroDip',0,0,0,''),
 ('03','m0015','NitCol',0,0,0,''),
 ('03','m0017','DroDroDip',0,0,0,''),
 ('03','m0020','DroDroDip',0,0,0,'brownish-yellow with peculiar ovipositor, short, narrow, and blunt, sclerotized'),
 ('03','m0022','DroDroDip',0,0,0,''),
 ('03','m0028','DroDroDip',0,0,0,''),
 ('03','m0029','DroDroDip',0,0,0,''),
 ('03','m0031','DroDroDip',0,0,0,'katepisternum almost completely yellow'),
 ('03','m0032','CamDolDip',0,0,0,''),
 ('03','m0034','LisMusDip',0,0,0,''),
 ('03','m0035','DroDroDip',0,0,0,''),
 ('03','m0036','BlaCarCol',0,0,0,''),
 ('03','m0041','DroDroDip',0,0,0,''),
 ('03','m0042','EurDolDip',0,0,0,''),
 ('03','m0043','DelHem',0,0,0,''),
 ('03','m0047','DroDroDip',0,0,0,''),
 ('03','m0048','DroDroDip',0,0,0,''),
 ('03','m0049','DroDroDip',0,0,0,'very large spots on crossveins and apices of veins'),
 ('03','m0050','DroDroDip',0,0,0,''),
 ('03','m0051','DroDroDip',0,0,0,''),
 ('03','m0053','S. DroDip',0,0,0,''),
 ('03','m0056','DroDroDip',0,0,0,''),
 ('03','m0058','NitCol',0,0,0,''),
 ('03','m0059','DroDroDip',0,0,0,''),
 ('03','m0060','DroDroDip',0,0,0,''),
 ('03','m0061','DroDroDip',0,0,0,''),
 ('03','m0064','DroDroDip',0,0,0,''),
 ('03','m0065','DroDroDip',0,0,0,''),
 ('03','m0066','DroDroDip',0,0,0,''),
 ('03','m0067','DroDroDip',0,0,0,'pleura all brown, front femur brown'),
 ('03','m0068','S. DroDip',0,0,0,'very un-Elmomyza like, look like Drosophila except for arista with two dorsal and no ventral rays, deep fork; ovipositor lightly sclerotized, setose'),
 ('03','m0069','DroDroDip',0,0,0,''),
 ('03','m0070','DroDroDip',0,0,0,''),
 ('03','m0072','DroDroDip',0,0,0,''),
 ('03','m0073','DroDroDip',0,0,0,''),
 ('03','m0074','DroDroDip',0,0,0,''),
 ('03','m0075','DroDroDip',0,0,0,''),
 ('03','m0076','DroDroDip',0,0,0,''),
 ('03','m0080','DroDroDip',0,0,0,''),
 ('03','m0081','DroDroDip',0,0,0,'all dark brown, cilia only on apical half of basitarsus, verticals not displaced'),
 ('03','m0082','DroDroDip',0,0,0,''),
 ('03','m0083','DroDroDip',0,0,0,'virtually identical to virgulata'),
 ('03','m0085','DroDroDip',0,0,0,''),
 ('03','m0086','DroDroDip',0,0,0,''),
 ('03','m0088','S. DroDip',0,0,0,''),
 ('03','m0089','DroDroDip',0,0,0,''),
 ('03','m0092','DroDroDip',0,0,0,''),
 ('03','m0093','S. DroDip',0,0,0,'genitalia appear similar to nigrosignata but lacking black median stripe'),
 ('03','m0094','DroDroDip',0,0,0,'same as m0090-09'),
 ('03','m0096','DroDroDip',0,0,0,''),
 ('03','m0097','S. DroDip',0,0,0,''),
 ('03','m0098','DroDroDip',0,0,0,''),
 ('03','m0099','DroDroDip',0,0,0,''),
 ('03','m0100','DroDroDip',0,0,0,'entire pleura yellow'),
 ('03','m0101','S. DroDip',0,0,0,''),
 ('03','m0102','DroDroDip',0,0,0,''),
 ('03','m0103','DroDroDip',0,0,0,'anterior katepisternal missing, but wing not infuscated'),
 ('03','m0104','DroDroDip',0,0,0,''),
 ('03','m0105','DroDroDip',0,0,0,''),
 ('03','m0107','DroDroDip',0,0,0,''),
 ('03','m0109','DroDroDip',0,0,0,''),
 ('03','m0112','DroDroDip',0,0,0,''),
 ('03','m0113','S. DroDip',0,0,0,''),
 ('03','m0116','DroDroDip',0,0,0,''),
 ('03','m0117','DroDroDip',0,0,0,''),
 ('03','m0119','DroDroDip',0,0,0,''),
 ('04','m0001','DroDroDip',0,0,0,''),
 ('04','m0003','S. DroDip',0,0,0,''),
 ('04','m0004','DroDroDip',0,0,0,'cilia similar but dorsal, no rim, coxa white, rest of legs black'),
 ('04','m0005','DroDroDip',0,0,0,''),
 ('04','m0006','DroDroDip',0,0,0,''),
 ('04','m0009','DroDroDip',0,0,0,''),
 ('04','m0010','DroDroDip',0,0,0,''),
 ('04','m0011','DroDroDip',0,0,0,'female: mesonotum with five stripes, including broad median'),
 ('04','m0012','DroDroDip',0,0,0,''),
 ('04','m0017','DroDroDip',0,0,0,''),
 ('04','m0022','DroDroDip',0,0,0,'group II spines all thin, similar'),
 ('04','m0028','DroDroDip',0,0,0,''),
 ('04','m0029','DroDroDip',0,0,0,''),
 ('04','m0031','DroDroDip',0,0,0,''),
 ('04','m0032','DelHem',0,0,0,''),
 ('04','m0035','DroDroDip',0,0,0,''),
 ('04','m0041','DroDroDip',0,0,0,''),
 ('04','m0042','DeiCraHym',0,0,0,''),
 ('04','m0047','DroDroDip',0,0,0,''),
 ('04','m0048','DroDroDip',0,0,0,''),
 ('04','m0050','DroDroDip',0,0,0,''),
 ('04','m0051','DroDroDip',0,0,0,''),
 ('04','m0053','S. DroDip',0,0,0,'pointed, sclerotized ovipositor, but only 6 acrostichal rows'),
 ('04','m0056','DroDroDip',0,0,0,''),
 ('04','m0059','DroDroDip',0,0,0,''),
 ('04','m0060','DroDroDip',0,0,0,''),
 ('04','m0061','DroDroDip',0,0,0,''),
 ('04','m0064','DroDroDip',0,0,0,''),
 ('04','m0065','DroDroDip',0,0,0,''),
 ('04','m0066','DroDroDip',0,0,0,''),
 ('04','m0067','DroDroDip',0,0,0,'upper half of pleura all brown, lower half all yellow, legs yellow, fore tibia with posterior setae like disticha, mesonotum dark except anterior, apical wing spot prominent'),
 ('04','m0069','DroDroDip',0,0,0,''),
 ('04','m0070','DroDroDip',0,0,0,''),
 ('04','m0072','DroDroDip',0,0,0,'female: metanotum dark, separated by a paler line (reddish brown in tanythrix); mesonotum more dark brown compared to reddish brown in tanythrix'),
 ('04','m0073','DroDroDip',0,0,0,''),
 ('04','m0074','DroDroDip',0,0,0,''),
 ('04','m0075','DroDroDip',0,0,0,''),
 ('04','m0076','DroDroDip',0,0,0,''),
 ('04','m0080','DroDroDip',0,0,0,''),
 ('04','m0081','DroDroDip',0,0,0,''),
 ('04','m0082','DroDroDip',0,0,0,''),
 ('04','m0083','DroDroDip',0,0,0,''),
 ('04','m0085','DroDroDip',0,0,0,''),
 ('04','m0086','SieBetHym',0,0,0,''),
 ('04','m0088','S. DroDip',0,0,0,'much smaller, almost all dark (no pale spot at base of abdomen), no additional scutellar setae'),
 ('04','m0089','DroDroDip',0,0,0,''),
 ('04','m0092','DroDroDip',0,0,0,''),
 ('04','m0096','DroDroDip',0,0,0,''),
 ('04','m0098','DroDroDip',0,0,0,''),
 ('04','m0099','DroDroDip',0,0,0,''),
 ('04','m0101','SieBetHym',0,0,0,''),
 ('04','m0102','DroDroDip',0,0,0,''),
 ('04','m0103','DroDroDip',0,0,0,'second antennal segment yellow'),
 ('04','m0104','DroDroDip',0,0,0,'with long posteroventral cilia on tibia like kauluai of Oahu'),
 ('04','m0105','DroDroDip',0,0,0,''),
 ('04','m0107','DroDroDip',0,0,0,''),
 ('04','m0109','DroDroDip',0,0,0,''),
 ('04','m0112','DroDroDip',0,0,0,''),
 ('04','m0113','CamDolDip',0,0,0,''),
 ('04','m0116','DroDroDip',0,0,0,''),
 ('04','m0117','DroDroDip',0,0,0,''),
 ('04','m0119','DroDroDip',0,0,0,''),
 ('05','m0001','DroDroDip',0,0,0,''),
 ('05','m0003','EurDolDip',0,0,0,''),
 ('05','m0004','DroDroDip',0,0,0,'one with picture wing-like ovipositor'),
 ('05','m0005','DroDroDip',0,0,0,''),
 ('05','m0006','DroDroDip',0,0,0,''),
 ('05','m0009','DroDroDip',0,0,0,''),
 ('05','m0010','DroDroDip',0,0,0,'one with unusual long vibrissae'),
 ('05','m0011','DroDroDip',0,0,0,''),
 ('05','m0012','DroDroDip',0,0,0,''),
 ('05','m0017','DroDroDip',0,0,0,''),
 ('05','m0022','CamDolDip',0,0,0,''),
 ('05','m0028','DroDroDip',0,0,0,''),
 ('05','m0029','S. DroDip',0,0,0,'all yellow'),
 ('05','m0035','S. DroDip',0,0,0,''),
 ('05','m0041','DroDroDip',0,0,0,''),
 ('05','m0042','NesLygHem',0,0,0,''),
 ('05','m0047','EurDolDip',0,0,0,''),
 ('05','m0048','DroDroDip',0,0,0,''),
 ('05','m0050','DroDroDip',0,0,0,''),
 ('05','m0056','DroDroDip',0,0,0,''),
 ('05','m0059','DroDroDip',0,0,0,''),
 ('05','m0060','DroDroDip',0,0,0,''),
 ('05','m0061','DroDroDip',0,0,0,''),
 ('05','m0064','DroDroDip',0,0,0,'suzukii, sulfurigaster, immigrans'),
 ('05','m0065','S. DroDip',0,0,0,'very un-Elmomyza like, look like Drosophila except for arista with two dorsal and no ventral rays, deep fork; ovipositor lightly sclerotized, setose'),
 ('05','m0066','DroDroDip',0,0,0,''),
 ('05','m0067','DroDroDip',0,0,0,''),
 ('05','m0069','DroDroDip',0,0,0,''),
 ('05','m0070','DroDroDip',0,0,0,''),
 ('05','m0072','DroDroDip',0,0,0,''),
 ('05','m0073','DroDroDip',0,0,0,''),
 ('05','m0074','DroDroDip',0,0,0,''),
 ('05','m0075','DroDroDip',0,0,0,''),
 ('05','m0076','DroDroDip',0,0,0,''),
 ('05','m0080','DroDroDip',0,0,0,''),
 ('05','m0081','DroDroDip',0,0,0,'apicoventral seta present'),
 ('05','m0083','DroDroDip',0,0,0,''),
 ('05','m0085','DroDroDip',0,0,0,''),
 ('05','m0089','DroDroDip',0,0,0,''),
 ('05','m0092','DroDroDip',0,0,0,''),
 ('05','m0096','DroDroDip',0,0,0,''),
 ('05','m0099','DroDroDip',0,0,0,''),
 ('05','m0102','DroDroDip',0,0,0,''),
 ('05','m0104','DroDroDip',0,0,0,''),
 ('05','m0107','S. DroDip',0,0,0,'much darker than specimens from flowers'),
 ('05','m0109','DroDroDip',0,0,0,''),
 ('05','m0112','S. DroDip',0,0,0,''),
 ('05','m0116','DroDroDip',0,0,0,''),
 ('05','m0117','DroDroDip',0,0,0,''),
 ('05','m0119','DroDroDip',0,0,0,''),
 ('06','m0001','LibDolDip',0,0,0,''),
 ('06','m0003','ChiDip',0,0,0,''),
 ('06','m0004','NitCol',0,0,0,''),
 ('06','m0005','DroDroDip',0,0,0,''),
 ('06','m0006','EurDolDip',0,0,0,''),
 ('06','m0009','DroDroDip',0,0,0,''),
 ('06','m0010','S. DroDip',0,0,0,''),
 ('06','m0011','S. DroDip',0,0,0,''),
 ('06','m0012','DroDroDip',0,0,0,''),
 ('06','m0017','DroDroDip',0,0,0,''),
 ('06','m0022','HemNeu',0,0,0,''),
 ('06','m0028','DroDroDip',0,0,0,''),
 ('06','m0029','S. DroDip',0,0,0,'black mesonotum, yellow pleura'),
 ('06','m0042','NesCicHem',0,0,0,''),
 ('06','m0050','DroDroDip',0,0,0,''),
 ('06','m0056','DroDroDip',0,0,0,''),
 ('06','m0059','DroDroDip',0,0,0,''),
 ('06','m0060','DroDroDip',0,0,0,''),
 ('06','m0061','DroDroDip',0,0,0,''),
 ('06','m0065','S. DroDip',0,0,0,'10 acrostichal rows'),
 ('06','m0066','DroDroDip',0,0,0,''),
 ('06','m0067','DroDroDip',0,0,0,'same wing marks but two humerals, lower half of pleura entirely yellow'),
 ('06','m0069','DroDroDip',0,0,0,''),
 ('06','m0070','S. DroDip',0,0,0,'male and one female pale, other female dark'),
 ('06','m0072','DroDroDip',0,0,0,''),
 ('06','m0073','DroDroDip',0,0,0,''),
 ('06','m0074','DroDroDip',0,0,0,''),
 ('06','m0075','DroDroDip',0,0,0,''),
 ('06','m0076','DroDroDip',0,0,0,''),
 ('06','m0080','DroDroDip',0,0,0,'yellow thorax with dark median stripe, dark pleura; may be two species, coloration slightly different'),
 ('06','m0081','DroDroDip',0,0,0,''),
 ('06','m0083','DroDroDip',0,0,0,'description of wing mark in key matches specimen, different from illustration'),
 ('06','m0085','DroDroDip',0,0,0,''),
 ('06','m0089','DroDroDip',0,0,0,''),
 ('06','m0092','DroDroDip',0,0,0,''),
 ('06','m0096','DroDroDip',0,0,0,''),
 ('06','m0099','DroDroDip',0,0,0,''),
 ('06','m0102','DroDroDip',0,0,0,''),
 ('06','m0104','DroDroDip',0,0,0,''),
 ('06','m0109','DroDroDip',0,0,0,''),
 ('06','m0116','DroDroDip',0,0,0,''),
 ('06','m0117','DroDroDip',0,0,0,''),
 ('06','m0119','DroDroDip',0,0,0,''),
 ('07','m0005','CamDolDip',0,0,0,''),
 ('07','m0010','S. DroDip',0,0,0,''),
 ('07','m0011','S. DroDip',0,0,0,''),
 ('07','m0012','DroDroDip',0,0,0,'no cilia, legs yellow except mid femur black, face &amp; front all black but antennae yellow, wings marked at base and apex'),
 ('07','m0017','DroDroDip',0,0,0,'appendage like paracracens but no T2 appendage, tibial row like cracens'),
 ('07','m0022','OrtMirHem',0,0,0,'red'),
 ('07','m0028','DroDroDip',0,0,0,''),
 ('07','m0050','DroDroDip',0,0,0,'one looks like modmouth'),
 ('07','m0056','S. DroDip',0,0,0,''),
 ('07','m0059','DroDroDip',0,0,0,''),
 ('07','m0060','DroDroDip',0,0,0,''),
 ('07','m0061','DroDroDip',0,0,0,''),
 ('07','m0066','DroDroDip',0,0,0,''),
 ('07','m0067','DroDroDip',0,0,0,''),
 ('07','m0069','CamDolDip',0,0,0,''),
 ('07','m0072','DroDroDip',0,0,0,''),
 ('07','m0073','CamDroDip',0,0,0,''),
 ('07','m0074','CamDolDip',0,0,0,''),
 ('07','m0075','DroDroDip',0,0,0,''),
 ('07','m0076','DroDroDip',0,0,0,''),
 ('07','m0080','DroDroDip',0,0,0,''),
 ('07','m0081','DroDroDip',0,0,0,''),
 ('07','m0085','DroDroDip',0,0,0,''),
 ('07','m0089','S. DroDip',0,0,0,'striped specimen is nr. decepta'),
 ('07','m0092','DroDroDip',0,0,0,''),
 ('07','m0096','DroDroDip',0,0,0,'same as m0090-09'),
 ('07','m0099','DroDroDip',0,0,0,''),
 ('07','m0102','DroDroDip',0,0,0,''),
 ('07','m0104','DroDroDip',0,0,0,''),
 ('07','m0116','DroDroDip',0,0,0,''),
 ('07','m0117','DroDroDip',0,0,0,''),
 ('07','m0119','DroDroDip',0,0,0,''),
 ('08','m0005','EurDolDip',0,0,0,''),
 ('08','m0010','CamDolDip',0,0,0,''),
 ('08','m0011','S. DroDip',0,0,0,''),
 ('08','m0012','DroDroDip',0,0,0,''),
 ('08','m0017','DroDroDip',0,0,0,''),
 ('08','m0022','OrtMirHem',0,0,0,'green'),
 ('08','m0028','DroDroDip',0,0,0,''),
 ('08','m0050','CamDolDip',0,0,0,''),
 ('08','m0059','CamDolDip',0,0,0,''),
 ('08','m0060','DroDroDip',0,0,0,''),
 ('08','m0061','DroDroDip',0,0,0,''),
 ('08','m0066','S. DroDip',0,0,0,'overall similar to Engiscap but no ventral rays; pointed wing, mesonotum yellow, pleura with two broad dark stripes, femora dark brown, tibiae banded'),
 ('08','m0067','DroDroDip',0,0,0,''),
 ('08','m0069','NesCicHem',0,0,0,''),
 ('08','m0072','DroDroDip',0,0,0,'predominantly one species'),
 ('08','m0073','EurDroDip',0,0,0,''),
 ('08','m0074','SieBetHym',0,0,0,''),
 ('08','m0075','DroDroDip',0,0,0,''),
 ('08','m0076','DroDroDip',0,0,0,''),
 ('08','m0080','S. DroDip',0,0,0,''),
 ('08','m0081','DroDroDip',0,0,0,''),
 ('08','m0085','DroDroDip',0,0,0,''),
 ('08','m0089','S. DroDip',0,0,0,''),
 ('08','m0092','DroDroDip',0,0,0,''),
 ('08','m0099','DroDroDip',0,0,0,''),
 ('08','m0102','DroDroDip',0,0,0,'also 3 females that appear to be simulans'),
 ('08','m0104','DroDroDip',0,0,0,''),
 ('08','m0116','DroDroDip',0,0,0,''),
 ('08','m0117','DroDroDip',0,0,0,''),
 ('08','m0119','S. DroDip',0,0,0,''),
 ('09','m0005','ChiDip',0,0,0,''),
 ('09','m0010','NitCol',0,0,0,''),
 ('09','m0012','DroDroDip',0,0,0,''),
 ('09','m0017','DroDroDip',0,0,0,''),
 ('09','m0028','DroDroDip',0,0,0,''),
 ('09','m0050','LisMusDip',0,0,0,''),
 ('09','m0060','DroDroDip',0,0,0,''),
 ('09','m0061','LisMusDip',0,0,0,''),
 ('09','m0067','DroDroDip',0,0,0,''),
 ('09','m0072','S. DroDip',0,0,0,''),
 ('09','m0074','OliCixHem',0,0,0,''),
 ('09','m0075','S. DroDip',0,0,0,''),
 ('09','m0076','DroDroDip',0,0,0,'2nd tarsal segment is very long and thin'),
 ('09','m0081','DroDroDip',0,0,0,''),
 ('09','m0085','S. DroDip',0,0,0,''),
 ('09','m0089','S. DroDip',0,0,0,'striped thorax like Tantalia, but genitalia different from mediopallens'),
 ('09','m0092','DroDroDip',0,0,0,'appears to be all one species; almost completely dark brown including legs and abdomen, short faint mark at apex of R4+5, extremely short ovipositor'),
 ('09','m0104','DroDroDip',0,0,0,''),
 ('09','m0116','S. DroDip',0,0,0,''),
 ('09','m0117','DroDroDip',0,0,0,''),
 ('09','m0119','CamDolDip',0,0,0,''),
 ('10','m0010','NesCicHem',0,0,0,'male is nymph'),
 ('10','m0012','DroDroDip',0,0,0,''),
 ('10','m0017','DroDroDip',0,0,0,''),
 ('10','m0028','S. DroDip',0,0,0,''),
 ('10','m0050','NitCol',0,0,0,''),
 ('10','m0060','DroDroDip',0,0,0,''),
 ('10','m0067','S. DroDip',0,0,0,''),
 ('10','m0072','NitCol',0,0,0,''),
 ('10','m0076','DroDroDip',0,0,0,''),
 ('10','m0081','DroDroDip',0,0,0,''),
 ('10','m0085','S. DroDip',0,0,0,''),
 ('10','m0089','CamDroDip',0,0,0,''),
 ('10','m0092','S. DroDip',0,0,0,''),
 ('10','m0104','DroDroDip',0,0,0,''),
 ('10','m0117','DroDroDip',0,0,0,''),
 ('10','m0119','SieBetHym',0,0,0,''),
 ('11','m0010','OrtDolDip',0,0,0,''),
 ('11','m0012','DroDroDip',0,0,0,''),
 ('11','m0017','S. DroDip',0,0,0,''),
 ('11','m0028','S. DroDip',0,0,0,''),
 ('11','m0060','S. DroDip',0,0,0,''),
 ('11','m0067','S. DroDip',0,0,0,''),
 ('11','m0076','DroDroDip',0,0,0,''),
 ('11','m0081','DroDroDip',0,0,0,''),
 ('11','m0089','AstAstDip',0,0,0,'two species'),
 ('11','m0104','SieBetHym',0,0,0,''),
 ('11','m0117','DroDroDip',0,0,0,'shining black, wings ink-dipped with broad mark on m xvein'),
 ('11','m0119','OrtMirHem',0,0,0,''),
 ('12','m0012','DroDroDip',0,0,0,''),
 ('12','m0017','CamDolDip',0,0,0,''),
 ('12','m0028','CamDolDip',0,0,0,''),
 ('12','m0067','CamDolDip',0,0,0,'olive green, wing membrane dark, tibiae banded'),
 ('12','m0076','CamDolDip',0,0,0,''),
 ('12','m0081','DroDroDip',0,0,0,''),
 ('12','m0089','SieBetHym',0,0,0,''),
 ('12','m0117','S. DroDip',0,0,0,'coloration identical to nigrosignata'),
 ('12','m0119','DelHem',0,0,0,''),
 ('13','m0012','S. DroDip',0,0,0,'at least 5 species'),
 ('13','m0028','EurDolDip',0,0,0,''),
 ('13','m0067','ArcDolDip',0,0,0,''),
 ('13','m0076','EurDolDip',0,0,0,''),
 ('13','m0081','DroDroDip',0,0,0,''),
 ('13','m0089','OrtMirHem',0,0,0,''),
 ('13','m0117','CamDolDip',0,0,0,''),
 ('14','m0012','S. DroDip',0,0,0,''),
 ('14','m0028','CepPipDip',0,0,0,''),
 ('14','m0067','MirHem',0,0,0,''),
 ('14','m0076','NesCicHem',0,0,0,''),
 ('14','m0089','PlaCerCol',0,0,0,''),
 ('14','m0117','NesDroDip',0,0,0,'2 species'),
 ('15','m0012','CamDolDip',0,0,0,'&gt;5 species'),
 ('15','m0067','NesCicHem',0,0,0,''),
 ('15','m0076','NesVesHym',0,0,0,''),
 ('15','m0117','MecCarCol',0,0,0,''),
 ('16','m0012','LisMusDip',0,0,0,''),
 ('16','m0067','SieBetHym',0,0,0,'clypeus raised but not carinate, prothorax orange'),
 ('17','m0012','DicLimDip',0,0,0,''),
 ('17','m0067','SpoIchHym',0,0,0,''),
 ('18','m0012','ChiDip',0,0,0,''),
 ('18','m0067','GryOrt',0,0,0,''),
 ('19','m0012','DelHem',0,0,0,''),
 ('20','m0012','NesCicHem',0,0,0,''),
 ('21','m0012','SieBetHym',0,0,0,''),
 ('[PH','test','[PH',1,0,1,'[PH');
/*!40000 ALTER TABLE `collection` ENABLE KEYS */;


--
-- Definition of table `collector`
--

DROP TABLE IF EXISTS `collector`;
CREATE TABLE `collector` (
  `abbr3_collector` char(3) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `middle_name` varchar(50) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `passwd` text,
  `abbr4_organization` char(4) DEFAULT NULL,
  `user_name` varchar(8) DEFAULT NULL,
  PRIMARY KEY (`abbr3_collector`),
  KEY `collector_FKIndex1` (`abbr4_organization`),
  CONSTRAINT `collector_ibfk_1` FOREIGN KEY (`abbr4_organization`) REFERENCES `organization` (`abbr4_organization`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `collector`
--

/*!40000 ALTER TABLE `collector` DISABLE KEYS */;
INSERT INTO `collector` (`abbr3_collector`,`first_name`,`last_name`,`middle_name`,`email`,`passwd`,`abbr4_organization`,`user_name`) VALUES 
 ('','','','','','','',''),
 ('DAN','[PH]','[PH]','[PH]','[PH]',NULL,'UHH',NULL),
 ('JEL','[PH]','[PH]','[PH]','[PH]',NULL,'UHH',NULL),
 ('JJO','[PH]','[PH]','[PH]','[PH]',NULL,'UHH',NULL),
 ('KMI','[PH]','[PH]','[PH]','[PH]',NULL,'UHH',NULL),
 ('KNM','[PH]','[PH]','[PH]','[PH]',NULL,'UHH',NULL),
 ('[PH','[PH','[PH','[PH','[PH','[PH','[PH','[PH');
/*!40000 ALTER TABLE `collector` ENABLE KEYS */;


--
-- Definition of table `container`
--

DROP TABLE IF EXISTS `container`;
CREATE TABLE `container` (
  `cabinet_code` char(5) NOT NULL,
  `box_code` char(9) NOT NULL,
  `section_code` char(9) NOT NULL,
  `abbr4_organization` char(4) NOT NULL,
  PRIMARY KEY (`cabinet_code`,`box_code`,`section_code`,`abbr4_organization`),
  KEY `container_FKIndex1` (`abbr4_organization`),
  CONSTRAINT `container_ibfk_1` FOREIGN KEY (`abbr4_organization`) REFERENCES `organization` (`abbr4_organization`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `container`
--

/*!40000 ALTER TABLE `container` DISABLE KEYS */;
INSERT INTO `container` (`cabinet_code`,`box_code`,`section_code`,`abbr4_organization`) VALUES 
 ('','','','test'),
 ('[PH','[PH','[PH','test'),
 ('[PH]','[PH]','[PH]','test'),
 ('[PH]','1','1','UHH'),
 ('[PH]','1','10','UHH'),
 ('[PH]','1','11','UHH'),
 ('[PH]','1','12','UHH'),
 ('[PH]','1','13','UHH'),
 ('[PH]','1','14','UHH'),
 ('[PH]','1','15','UHH'),
 ('[PH]','1','16','UHH'),
 ('[PH]','1','17','UHH'),
 ('[PH]','1','18','UHH'),
 ('[PH]','1','19','UHH'),
 ('[PH]','1','2','UHH'),
 ('[PH]','1','20','UHH'),
 ('[PH]','1','21','UHH'),
 ('[PH]','1','22','UHH'),
 ('[PH]','1','23','UHH'),
 ('[PH]','1','24','UHH'),
 ('[PH]','1','25','UHH'),
 ('[PH]','1','26','UHH'),
 ('[PH]','1','27','UHH'),
 ('[PH]','1','28','UHH'),
 ('[PH]','1','29','UHH'),
 ('[PH]','1','3','UHH'),
 ('[PH]','1','30','UHH'),
 ('[PH]','1','31','UHH'),
 ('[PH]','1','32','UHH'),
 ('[PH]','1','33','UHH'),
 ('[PH]','1','34','UHH'),
 ('[PH]','1','35','UHH'),
 ('[PH]','1','36','UHH'),
 ('[PH]','1','37','UHH'),
 ('[PH]','1','38','UHH'),
 ('[PH]','1','39','UHH'),
 ('[PH]','1','4','UHH'),
 ('[PH]','1','40','UHH'),
 ('[PH]','1','41','UHH'),
 ('[PH]','1','42','UHH'),
 ('[PH]','1','43','UHH'),
 ('[PH]','1','44','UHH'),
 ('[PH]','1','45','UHH'),
 ('[PH]','1','46','UHH'),
 ('[PH]','1','47','UHH'),
 ('[PH]','1','48','UHH'),
 ('[PH]','1','49','UHH'),
 ('[PH]','1','5','UHH'),
 ('[PH]','1','50','UHH'),
 ('[PH]','1','51','UHH'),
 ('[PH]','1','52','UHH'),
 ('[PH]','1','53','UHH'),
 ('[PH]','1','54','UHH'),
 ('[PH]','1','55','UHH'),
 ('[PH]','1','56','UHH'),
 ('[PH]','1','57','UHH'),
 ('[PH]','1','58','UHH'),
 ('[PH]','1','59','UHH'),
 ('[PH]','1','6','UHH'),
 ('[PH]','1','60','UHH'),
 ('[PH]','1','61','UHH'),
 ('[PH]','1','62','UHH'),
 ('[PH]','1','7','UHH'),
 ('[PH]','1','8','UHH'),
 ('[PH]','1','9','UHH'),
 ('[PH]','10','1','UHH'),
 ('[PH]','10','10','UHH'),
 ('[PH]','10','11','UHH'),
 ('[PH]','10','12','UHH'),
 ('[PH]','10','13','UHH'),
 ('[PH]','10','14','UHH'),
 ('[PH]','10','15','UHH'),
 ('[PH]','10','16','UHH'),
 ('[PH]','10','17','UHH'),
 ('[PH]','10','18','UHH'),
 ('[PH]','10','19','UHH'),
 ('[PH]','10','2','UHH'),
 ('[PH]','10','20','UHH'),
 ('[PH]','10','21','UHH'),
 ('[PH]','10','22','UHH'),
 ('[PH]','10','23','UHH'),
 ('[PH]','10','24','UHH'),
 ('[PH]','10','25','UHH'),
 ('[PH]','10','26','UHH'),
 ('[PH]','10','3','UHH'),
 ('[PH]','10','4','UHH'),
 ('[PH]','10','5','UHH'),
 ('[PH]','10','6','UHH'),
 ('[PH]','10','7','UHH'),
 ('[PH]','10','8','UHH'),
 ('[PH]','10','9','UHH'),
 ('[PH]','2','1','UHH'),
 ('[PH]','2','10','UHH'),
 ('[PH]','2','11','UHH'),
 ('[PH]','2','12','UHH'),
 ('[PH]','2','13','UHH'),
 ('[PH]','2','14','UHH'),
 ('[PH]','2','15','UHH'),
 ('[PH]','2','16','UHH'),
 ('[PH]','2','17','UHH'),
 ('[PH]','2','18','UHH'),
 ('[PH]','2','19','UHH'),
 ('[PH]','2','2','UHH'),
 ('[PH]','2','20','UHH'),
 ('[PH]','2','21','UHH'),
 ('[PH]','2','22','UHH'),
 ('[PH]','2','23','UHH'),
 ('[PH]','2','24','UHH'),
 ('[PH]','2','25','UHH'),
 ('[PH]','2','26','UHH'),
 ('[PH]','2','27','UHH'),
 ('[PH]','2','28','UHH'),
 ('[PH]','2','29','UHH'),
 ('[PH]','2','3','UHH'),
 ('[PH]','2','30','UHH'),
 ('[PH]','2','31','UHH'),
 ('[PH]','2','32','UHH'),
 ('[PH]','2','33','UHH'),
 ('[PH]','2','34','UHH'),
 ('[PH]','2','35','UHH'),
 ('[PH]','2','36','UHH'),
 ('[PH]','2','37','UHH'),
 ('[PH]','2','38','UHH'),
 ('[PH]','2','39','UHH'),
 ('[PH]','2','4','UHH'),
 ('[PH]','2','40','UHH'),
 ('[PH]','2','41','UHH'),
 ('[PH]','2','42','UHH'),
 ('[PH]','2','43','UHH'),
 ('[PH]','2','44','UHH'),
 ('[PH]','2','45','UHH'),
 ('[PH]','2','46','UHH'),
 ('[PH]','2','47','UHH'),
 ('[PH]','2','48','UHH'),
 ('[PH]','2','49','UHH'),
 ('[PH]','2','5','UHH'),
 ('[PH]','2','50','UHH'),
 ('[PH]','2','51','UHH'),
 ('[PH]','2','52','UHH'),
 ('[PH]','2','53','UHH'),
 ('[PH]','2','54','UHH'),
 ('[PH]','2','55','UHH'),
 ('[PH]','2','56','UHH'),
 ('[PH]','2','57','UHH'),
 ('[PH]','2','58','UHH'),
 ('[PH]','2','59','UHH'),
 ('[PH]','2','6','UHH'),
 ('[PH]','2','60','UHH'),
 ('[PH]','2','61','UHH'),
 ('[PH]','2','62','UHH'),
 ('[PH]','2','7','UHH'),
 ('[PH]','2','8','UHH'),
 ('[PH]','2','9','UHH'),
 ('[PH]','3','1','UHH'),
 ('[PH]','3','10','UHH'),
 ('[PH]','3','11','UHH'),
 ('[PH]','3','12','UHH'),
 ('[PH]','3','13','UHH'),
 ('[PH]','3','14','UHH'),
 ('[PH]','3','15','UHH'),
 ('[PH]','3','16','UHH'),
 ('[PH]','3','17','UHH'),
 ('[PH]','3','18','UHH'),
 ('[PH]','3','19','UHH'),
 ('[PH]','3','2','UHH'),
 ('[PH]','3','20','UHH'),
 ('[PH]','3','21','UHH'),
 ('[PH]','3','22','UHH'),
 ('[PH]','3','23','UHH'),
 ('[PH]','3','24','UHH'),
 ('[PH]','3','25','UHH'),
 ('[PH]','3','26','UHH'),
 ('[PH]','3','27','UHH'),
 ('[PH]','3','28','UHH'),
 ('[PH]','3','29','UHH'),
 ('[PH]','3','3','UHH'),
 ('[PH]','3','30','UHH'),
 ('[PH]','3','31','UHH'),
 ('[PH]','3','32','UHH'),
 ('[PH]','3','33','UHH'),
 ('[PH]','3','34','UHH'),
 ('[PH]','3','35','UHH'),
 ('[PH]','3','36','UHH'),
 ('[PH]','3','37','UHH'),
 ('[PH]','3','38','UHH'),
 ('[PH]','3','39','UHH'),
 ('[PH]','3','4','UHH'),
 ('[PH]','3','40','UHH'),
 ('[PH]','3','41','UHH'),
 ('[PH]','3','42','UHH'),
 ('[PH]','3','43','UHH'),
 ('[PH]','3','44','UHH'),
 ('[PH]','3','45','UHH'),
 ('[PH]','3','46','UHH'),
 ('[PH]','3','47','UHH'),
 ('[PH]','3','48','UHH'),
 ('[PH]','3','49','UHH'),
 ('[PH]','3','5','UHH'),
 ('[PH]','3','50','UHH'),
 ('[PH]','3','51','UHH'),
 ('[PH]','3','52','UHH'),
 ('[PH]','3','53','UHH'),
 ('[PH]','3','54','UHH'),
 ('[PH]','3','55','UHH'),
 ('[PH]','3','56','UHH'),
 ('[PH]','3','57','UHH'),
 ('[PH]','3','58','UHH'),
 ('[PH]','3','59','UHH'),
 ('[PH]','3','6','UHH'),
 ('[PH]','3','60','UHH'),
 ('[PH]','3','61','UHH'),
 ('[PH]','3','62','UHH'),
 ('[PH]','3','7','UHH'),
 ('[PH]','3','8','UHH'),
 ('[PH]','3','9','UHH'),
 ('[PH]','4','1','UHH'),
 ('[PH]','4','10','UHH'),
 ('[PH]','4','11','UHH'),
 ('[PH]','4','12','UHH'),
 ('[PH]','4','13','UHH'),
 ('[PH]','4','14','UHH'),
 ('[PH]','4','15','UHH'),
 ('[PH]','4','16','UHH'),
 ('[PH]','4','17','UHH'),
 ('[PH]','4','18','UHH'),
 ('[PH]','4','19','UHH'),
 ('[PH]','4','2','UHH'),
 ('[PH]','4','20','UHH'),
 ('[PH]','4','21','UHH'),
 ('[PH]','4','22','UHH'),
 ('[PH]','4','23','UHH'),
 ('[PH]','4','24','UHH'),
 ('[PH]','4','25','UHH'),
 ('[PH]','4','26','UHH'),
 ('[PH]','4','27','UHH'),
 ('[PH]','4','28','UHH'),
 ('[PH]','4','29','UHH'),
 ('[PH]','4','3','UHH'),
 ('[PH]','4','30','UHH'),
 ('[PH]','4','31','UHH'),
 ('[PH]','4','32','UHH'),
 ('[PH]','4','33','UHH'),
 ('[PH]','4','34','UHH'),
 ('[PH]','4','35','UHH'),
 ('[PH]','4','36','UHH'),
 ('[PH]','4','37','UHH'),
 ('[PH]','4','38','UHH'),
 ('[PH]','4','39','UHH'),
 ('[PH]','4','4','UHH'),
 ('[PH]','4','40','UHH'),
 ('[PH]','4','41','UHH'),
 ('[PH]','4','42','UHH'),
 ('[PH]','4','43','UHH'),
 ('[PH]','4','44','UHH'),
 ('[PH]','4','45','UHH'),
 ('[PH]','4','46','UHH'),
 ('[PH]','4','47','UHH'),
 ('[PH]','4','48','UHH'),
 ('[PH]','4','49','UHH'),
 ('[PH]','4','5','UHH'),
 ('[PH]','4','50','UHH'),
 ('[PH]','4','51','UHH'),
 ('[PH]','4','52','UHH'),
 ('[PH]','4','53','UHH'),
 ('[PH]','4','54','UHH'),
 ('[PH]','4','55','UHH'),
 ('[PH]','4','56','UHH'),
 ('[PH]','4','57','UHH'),
 ('[PH]','4','58','UHH'),
 ('[PH]','4','59','UHH'),
 ('[PH]','4','6','UHH'),
 ('[PH]','4','60','UHH'),
 ('[PH]','4','61','UHH'),
 ('[PH]','4','62','UHH'),
 ('[PH]','4','7','UHH'),
 ('[PH]','4','8','UHH'),
 ('[PH]','4','9','UHH'),
 ('[PH]','5','1','UHH'),
 ('[PH]','5','10','UHH'),
 ('[PH]','5','11','UHH'),
 ('[PH]','5','12','UHH'),
 ('[PH]','5','13','UHH'),
 ('[PH]','5','14','UHH'),
 ('[PH]','5','15','UHH'),
 ('[PH]','5','16','UHH'),
 ('[PH]','5','17','UHH'),
 ('[PH]','5','18','UHH'),
 ('[PH]','5','19','UHH'),
 ('[PH]','5','2','UHH'),
 ('[PH]','5','20','UHH'),
 ('[PH]','5','21','UHH'),
 ('[PH]','5','22','UHH'),
 ('[PH]','5','23','UHH'),
 ('[PH]','5','24','UHH'),
 ('[PH]','5','25','UHH'),
 ('[PH]','5','26','UHH'),
 ('[PH]','5','27','UHH'),
 ('[PH]','5','28','UHH'),
 ('[PH]','5','29','UHH'),
 ('[PH]','5','3','UHH'),
 ('[PH]','5','30','UHH'),
 ('[PH]','5','31','UHH'),
 ('[PH]','5','32','UHH'),
 ('[PH]','5','33','UHH'),
 ('[PH]','5','34','UHH'),
 ('[PH]','5','35','UHH'),
 ('[PH]','5','36','UHH'),
 ('[PH]','5','37','UHH'),
 ('[PH]','5','38','UHH'),
 ('[PH]','5','39','UHH'),
 ('[PH]','5','4','UHH'),
 ('[PH]','5','40','UHH'),
 ('[PH]','5','41','UHH'),
 ('[PH]','5','42','UHH'),
 ('[PH]','5','43','UHH'),
 ('[PH]','5','44','UHH'),
 ('[PH]','5','45','UHH'),
 ('[PH]','5','46','UHH'),
 ('[PH]','5','47','UHH'),
 ('[PH]','5','48','UHH'),
 ('[PH]','5','49','UHH'),
 ('[PH]','5','5','UHH'),
 ('[PH]','5','50','UHH'),
 ('[PH]','5','51','UHH'),
 ('[PH]','5','52','UHH'),
 ('[PH]','5','53','UHH'),
 ('[PH]','5','54','UHH'),
 ('[PH]','5','55','UHH'),
 ('[PH]','5','56','UHH'),
 ('[PH]','5','57','UHH'),
 ('[PH]','5','58','UHH'),
 ('[PH]','5','59','UHH'),
 ('[PH]','5','6','UHH'),
 ('[PH]','5','60','UHH'),
 ('[PH]','5','61','UHH'),
 ('[PH]','5','62','UHH'),
 ('[PH]','5','7','UHH'),
 ('[PH]','5','8','UHH'),
 ('[PH]','5','9','UHH'),
 ('[PH]','6','1','UHH'),
 ('[PH]','6','10','UHH'),
 ('[PH]','6','11','UHH'),
 ('[PH]','6','12','UHH'),
 ('[PH]','6','13','UHH'),
 ('[PH]','6','14','UHH'),
 ('[PH]','6','15','UHH'),
 ('[PH]','6','16','UHH'),
 ('[PH]','6','17','UHH'),
 ('[PH]','6','18','UHH'),
 ('[PH]','6','19','UHH'),
 ('[PH]','6','2','UHH'),
 ('[PH]','6','20','UHH'),
 ('[PH]','6','21','UHH'),
 ('[PH]','6','22','UHH'),
 ('[PH]','6','23','UHH'),
 ('[PH]','6','24','UHH'),
 ('[PH]','6','25','UHH'),
 ('[PH]','6','26','UHH'),
 ('[PH]','6','27','UHH'),
 ('[PH]','6','28','UHH'),
 ('[PH]','6','29','UHH'),
 ('[PH]','6','3','UHH'),
 ('[PH]','6','30','UHH'),
 ('[PH]','6','31','UHH'),
 ('[PH]','6','32','UHH'),
 ('[PH]','6','33','UHH'),
 ('[PH]','6','34','UHH'),
 ('[PH]','6','35','UHH'),
 ('[PH]','6','36','UHH'),
 ('[PH]','6','37','UHH'),
 ('[PH]','6','38','UHH'),
 ('[PH]','6','39','UHH'),
 ('[PH]','6','4','UHH'),
 ('[PH]','6','40','UHH'),
 ('[PH]','6','41','UHH'),
 ('[PH]','6','42','UHH'),
 ('[PH]','6','43','UHH'),
 ('[PH]','6','44','UHH'),
 ('[PH]','6','45','UHH'),
 ('[PH]','6','46','UHH'),
 ('[PH]','6','47','UHH'),
 ('[PH]','6','48','UHH'),
 ('[PH]','6','49','UHH'),
 ('[PH]','6','5','UHH'),
 ('[PH]','6','50','UHH'),
 ('[PH]','6','51','UHH'),
 ('[PH]','6','52','UHH'),
 ('[PH]','6','53','UHH'),
 ('[PH]','6','54','UHH'),
 ('[PH]','6','55','UHH'),
 ('[PH]','6','56','UHH'),
 ('[PH]','6','57','UHH'),
 ('[PH]','6','58','UHH'),
 ('[PH]','6','59','UHH'),
 ('[PH]','6','6','UHH'),
 ('[PH]','6','60','UHH'),
 ('[PH]','6','61','UHH'),
 ('[PH]','6','62','UHH'),
 ('[PH]','6','7','UHH'),
 ('[PH]','6','8','UHH'),
 ('[PH]','6','9','UHH'),
 ('[PH]','7','1','UHH'),
 ('[PH]','7','10','UHH'),
 ('[PH]','7','11','UHH'),
 ('[PH]','7','12','UHH'),
 ('[PH]','7','13','UHH'),
 ('[PH]','7','14','UHH'),
 ('[PH]','7','15','UHH'),
 ('[PH]','7','16','UHH'),
 ('[PH]','7','17','UHH'),
 ('[PH]','7','18','UHH'),
 ('[PH]','7','19','UHH'),
 ('[PH]','7','2','UHH'),
 ('[PH]','7','20','UHH'),
 ('[PH]','7','21','UHH'),
 ('[PH]','7','22','UHH'),
 ('[PH]','7','23','UHH'),
 ('[PH]','7','24','UHH'),
 ('[PH]','7','25','UHH'),
 ('[PH]','7','26','UHH'),
 ('[PH]','7','27','UHH'),
 ('[PH]','7','28','UHH'),
 ('[PH]','7','29','UHH'),
 ('[PH]','7','3','UHH'),
 ('[PH]','7','30','UHH'),
 ('[PH]','7','31','UHH'),
 ('[PH]','7','32','UHH'),
 ('[PH]','7','33','UHH'),
 ('[PH]','7','34','UHH'),
 ('[PH]','7','35','UHH'),
 ('[PH]','7','36','UHH'),
 ('[PH]','7','37','UHH'),
 ('[PH]','7','38','UHH'),
 ('[PH]','7','39','UHH'),
 ('[PH]','7','4','UHH'),
 ('[PH]','7','40','UHH'),
 ('[PH]','7','41','UHH'),
 ('[PH]','7','42','UHH'),
 ('[PH]','7','43','UHH'),
 ('[PH]','7','44','UHH'),
 ('[PH]','7','45','UHH'),
 ('[PH]','7','46','UHH'),
 ('[PH]','7','47','UHH'),
 ('[PH]','7','48','UHH'),
 ('[PH]','7','49','UHH'),
 ('[PH]','7','5','UHH'),
 ('[PH]','7','50','UHH'),
 ('[PH]','7','51','UHH'),
 ('[PH]','7','52','UHH'),
 ('[PH]','7','53','UHH'),
 ('[PH]','7','54','UHH'),
 ('[PH]','7','55','UHH'),
 ('[PH]','7','56','UHH'),
 ('[PH]','7','57','UHH'),
 ('[PH]','7','58','UHH'),
 ('[PH]','7','59','UHH'),
 ('[PH]','7','6','UHH'),
 ('[PH]','7','60','UHH'),
 ('[PH]','7','61','UHH'),
 ('[PH]','7','62','UHH'),
 ('[PH]','7','7','UHH'),
 ('[PH]','7','8','UHH'),
 ('[PH]','7','9','UHH'),
 ('[PH]','8','1','UHH'),
 ('[PH]','8','10','UHH'),
 ('[PH]','8','11','UHH'),
 ('[PH]','8','12','UHH'),
 ('[PH]','8','13','UHH'),
 ('[PH]','8','14','UHH'),
 ('[PH]','8','15','UHH'),
 ('[PH]','8','16','UHH'),
 ('[PH]','8','17','UHH'),
 ('[PH]','8','18','UHH'),
 ('[PH]','8','19','UHH'),
 ('[PH]','8','2','UHH'),
 ('[PH]','8','20','UHH'),
 ('[PH]','8','21','UHH'),
 ('[PH]','8','22','UHH'),
 ('[PH]','8','23','UHH'),
 ('[PH]','8','24','UHH'),
 ('[PH]','8','25','UHH'),
 ('[PH]','8','26','UHH'),
 ('[PH]','8','27','UHH'),
 ('[PH]','8','28','UHH'),
 ('[PH]','8','29','UHH'),
 ('[PH]','8','3','UHH'),
 ('[PH]','8','30','UHH'),
 ('[PH]','8','31','UHH'),
 ('[PH]','8','32','UHH'),
 ('[PH]','8','33','UHH'),
 ('[PH]','8','34','UHH'),
 ('[PH]','8','35','UHH'),
 ('[PH]','8','36','UHH'),
 ('[PH]','8','37','UHH'),
 ('[PH]','8','38','UHH'),
 ('[PH]','8','39','UHH'),
 ('[PH]','8','4','UHH'),
 ('[PH]','8','40','UHH'),
 ('[PH]','8','41','UHH'),
 ('[PH]','8','42','UHH'),
 ('[PH]','8','43','UHH'),
 ('[PH]','8','44','UHH'),
 ('[PH]','8','45','UHH'),
 ('[PH]','8','46','UHH'),
 ('[PH]','8','47','UHH'),
 ('[PH]','8','48','UHH'),
 ('[PH]','8','49','UHH'),
 ('[PH]','8','5','UHH'),
 ('[PH]','8','50','UHH'),
 ('[PH]','8','51','UHH'),
 ('[PH]','8','52','UHH'),
 ('[PH]','8','53','UHH'),
 ('[PH]','8','54','UHH'),
 ('[PH]','8','55','UHH'),
 ('[PH]','8','56','UHH'),
 ('[PH]','8','57','UHH'),
 ('[PH]','8','58','UHH'),
 ('[PH]','8','59','UHH'),
 ('[PH]','8','6','UHH'),
 ('[PH]','8','60','UHH'),
 ('[PH]','8','61','UHH'),
 ('[PH]','8','62','UHH'),
 ('[PH]','8','7','UHH'),
 ('[PH]','8','8','UHH'),
 ('[PH]','8','9','UHH'),
 ('[PH]','9','1','UHH'),
 ('[PH]','9','10','UHH'),
 ('[PH]','9','11','UHH'),
 ('[PH]','9','12','UHH'),
 ('[PH]','9','13','UHH'),
 ('[PH]','9','14','UHH'),
 ('[PH]','9','15','UHH'),
 ('[PH]','9','16','UHH'),
 ('[PH]','9','17','UHH'),
 ('[PH]','9','18','UHH'),
 ('[PH]','9','19','UHH'),
 ('[PH]','9','2','UHH'),
 ('[PH]','9','20','UHH'),
 ('[PH]','9','21','UHH'),
 ('[PH]','9','22','UHH'),
 ('[PH]','9','23','UHH'),
 ('[PH]','9','24','UHH'),
 ('[PH]','9','25','UHH'),
 ('[PH]','9','26','UHH'),
 ('[PH]','9','27','UHH'),
 ('[PH]','9','28','UHH'),
 ('[PH]','9','29','UHH'),
 ('[PH]','9','3','UHH'),
 ('[PH]','9','30','UHH'),
 ('[PH]','9','31','UHH'),
 ('[PH]','9','32','UHH'),
 ('[PH]','9','33','UHH'),
 ('[PH]','9','34','UHH'),
 ('[PH]','9','35','UHH'),
 ('[PH]','9','36','UHH'),
 ('[PH]','9','37','UHH'),
 ('[PH]','9','38','UHH'),
 ('[PH]','9','39','UHH'),
 ('[PH]','9','4','UHH'),
 ('[PH]','9','40','UHH'),
 ('[PH]','9','41','UHH'),
 ('[PH]','9','42','UHH'),
 ('[PH]','9','43','UHH'),
 ('[PH]','9','44','UHH'),
 ('[PH]','9','45','UHH'),
 ('[PH]','9','46','UHH'),
 ('[PH]','9','47','UHH'),
 ('[PH]','9','48','UHH'),
 ('[PH]','9','49','UHH'),
 ('[PH]','9','5','UHH'),
 ('[PH]','9','50','UHH'),
 ('[PH]','9','51','UHH'),
 ('[PH]','9','52','UHH'),
 ('[PH]','9','53','UHH'),
 ('[PH]','9','54','UHH'),
 ('[PH]','9','55','UHH'),
 ('[PH]','9','56','UHH'),
 ('[PH]','9','57','UHH'),
 ('[PH]','9','58','UHH'),
 ('[PH]','9','59','UHH'),
 ('[PH]','9','6','UHH'),
 ('[PH]','9','60','UHH'),
 ('[PH]','9','61','UHH'),
 ('[PH]','9','62','UHH'),
 ('[PH]','9','7','UHH'),
 ('[PH]','9','8','UHH'),
 ('[PH]','9','9','UHH'),
 ('[PH]','[PH]','[PH]','UHH'),
 ('[PH','[PH','[PH','[PH');
/*!40000 ALTER TABLE `container` ENABLE KEYS */;


--
-- Definition of table `dna`
--

DROP TABLE IF EXISTS `dna`;
CREATE TABLE `dna` (
  `extraction_code` char(9) NOT NULL,
  `section_code` char(9) NOT NULL,
  `box_code` char(9) NOT NULL,
  `cabinet_code` char(5) NOT NULL,
  `abbr4_organization` char(4) NOT NULL,
  `sequence` text NOT NULL,
  `sequence_name` varchar(50) NOT NULL,
  `primer_name` varchar(50) NOT NULL,
  PRIMARY KEY (`extraction_code`),
  KEY `dna_FKIndex2` (`abbr4_organization`,`cabinet_code`,`box_code`,`section_code`),
  CONSTRAINT `dna_ibfk_1` FOREIGN KEY (`abbr4_organization`, `cabinet_code`, `box_code`, `section_code`) REFERENCES `container` (`abbr4_organization`, `cabinet_code`, `box_code`, `section_code`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dna`
--

/*!40000 ALTER TABLE `dna` DISABLE KEYS */;
/*!40000 ALTER TABLE `dna` ENABLE KEYS */;


--
-- Definition of table `dna_media`
--

DROP TABLE IF EXISTS `dna_media`;
CREATE TABLE `dna_media` (
  `extraction_code` char(9) NOT NULL,
  `media_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`extraction_code`,`media_id`),
  KEY `dna_media_FKIndex1` (`extraction_code`),
  KEY `dna_media_FKIndex2` (`media_id`),
  CONSTRAINT `dna_media_ibfk_1` FOREIGN KEY (`extraction_code`) REFERENCES `dna` (`extraction_code`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `dna_media_ibfk_2` FOREIGN KEY (`media_id`) REFERENCES `media` (`media_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dna_media`
--

/*!40000 ALTER TABLE `dna_media` DISABLE KEYS */;
/*!40000 ALTER TABLE `dna_media` ENABLE KEYS */;


--
-- Definition of table `event`
--

DROP TABLE IF EXISTS `event`;
CREATE TABLE `event` (
  `event_code` char(9) NOT NULL,
  `abbr3_collector` char(3) NOT NULL,
  `locality_name` varchar(100) NOT NULL,
  `reserve_name` char(20) NOT NULL,
  `island_name` char(10) NOT NULL,
  `date` date NOT NULL,
  `event_note` text,
  PRIMARY KEY (`event_code`),
  KEY `event_FKIndex1` (`island_name`,`reserve_name`,`locality_name`),
  KEY `event_FKIndex2` (`abbr3_collector`),
  CONSTRAINT `event_ibfk_1` FOREIGN KEY (`island_name`, `reserve_name`, `locality_name`) REFERENCES `location` (`island_name`, `reserve_name`, `locality_name`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `event_ibfk_2` FOREIGN KEY (`abbr3_collector`) REFERENCES `collector` (`abbr3_collector`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event`
--

/*!40000 ALTER TABLE `event` DISABLE KEYS */;
INSERT INTO `event` (`event_code`,`abbr3_collector`,`locality_name`,`reserve_name`,`island_name`,`date`,`event_note`) VALUES 
 ('','','','Puu Kukui (PK)\n','M\n','0000-00-00',''),
 ('m0001','KNM','Kehena, Honokane Nui rim','Ponoholo Ranch','Hawaii','2009-05-20','sweeping'),
 ('m0002','KNM','Kehena, Honokane Nui rim','Ponoholo Ranch','Hawaii','2009-05-20','on Cheirodendron'),
 ('m0003','KNM','Kehena, Pololu rim','Ponoholo Ranch','Hawaii','2009-05-20','on Melicope'),
 ('m0004','KNM','Kilohana exclosure','Puu O Umi','Hawaii','2009-05-22','on bait sponge'),
 ('m0005','KNM','Kilohana exclosure','Puu O Umi','Hawaii','2009-05-22','sweeping'),
 ('m0006','KNM','Kilohana exclosure','Puu O Umi','Hawaii','2009-05-22','on leaves'),
 ('m0007','KNM','Kilohana exclosure','Puu O Umi','Hawaii','2009-05-22','on ground'),
 ('m0008','KNM','Kilohana exclosure','Puu O Umi','Hawaii','2009-05-22','on Clermontia'),
 ('m0009','KNM','Maile Trail','Waikamoi','Maui','2009-06-01','at bait sponge'),
 ('m0010','KNM','Maile Trail','Waikamoi','Maui','2009-06-01','sweeping'),
 ('m0011','KNM','Piinaau Ridge east','Waikamoi','Maui','2009-06-02','at bait sponge'),
 ('m0012','KNM','Piinaau Ridge east','Waikamoi','Maui','2009-06-02','sweeping'),
 ('m0013','KNM','Piinaau Ridge east','Waikamoi','Maui','2009-06-02',''),
 ('m0014','KNM','Piinaau Ridge east','Waikamoi','Maui','2009-06-02','on Melicope clusiifolia'),
 ('m0015','KNM','FBS transect 3','Waikamoi','Maui','2009-06-03','at bait sponge'),
 ('m0016','KNM','FBS transect 3','Waikamoi','Maui','2009-06-03','at bait sponge'),
 ('m0017','KNM','FBS transect 3','Waikamoi','Maui','2009-06-03','under leaves'),
 ('m0018','KNM','FBS transect 3','Waikamoi','Maui','2009-06-03','in copula on Cler. tub.'),
 ('m0019','KNM','FBS transect 3','Waikamoi','Maui','2009-06-03','in copula on Cler. tub.'),
 ('m0020','KNM','Kahana Valley','Puu Kukui Preserve','Maui','2009-06-04','at bait sponge nr. Pisonia'),
 ('m0021','KNM','Kahana Valley','Puu Kukui Preserve','Maui','2009-06-04','at BioLure trap'),
 ('m0022','KNM','Kahana Valley','Puu Kukui Preserve','Maui','2009-06-04','sweeping'),
 ('m0023','KNM','Kahana Valley','Puu Kukui Preserve','Maui','2009-06-04','on rocks in streambed'),
 ('m0024','KNM','Kahana Valley','Puu Kukui Preserve','Maui','2009-06-04','on Touchardia'),
 ('m0025','KNM','Kahana Valley','Puu Kukui Preserve','Maui','2009-06-04','on Cyrtandra'),
 ('m0026','DAN','Kahana Valley','Puu Kukui Preserve','Maui','2009-06-04',''),
 ('m0027','JJO','Puu Kukui trail','Puu Kukui Preserve','Maui','2009-06-04','in flowers of Cler. arb.'),
 ('m0028','KNM','Puu Kukui trail','Puu Kukui Preserve','Maui','2009-06-05','under leaves'),
 ('m0029','KNM','Puu Kukui trail','Puu Kukui Preserve','Maui','2009-06-05','on Cyanea leaves &amp; flowers'),
 ('m0030','KNM','Puu Kukui trail','Puu Kukui Preserve','Maui','2009-06-05','on Melicope'),
 ('m0031','KNM','Puu Kukui trail','Puu Kukui Preserve','Maui','2009-06-05','under leaves'),
 ('m0032','KNM','Puu Kukui bog','Puu Kukui Preserve','Maui','2009-06-05','on Lobelia leaves'),
 ('m0033','KNM','Puu Kukui bog','Puu Kukui Preserve','Maui','2009-06-05','in Lobelia seed pod'),
 ('m0034','KNM','Puu Kukui summit','Puu Kukui Preserve','Maui','2009-06-05','under Melicope leaves'),
 ('m0035','KNM','Puu Kukui trail','Puu Kukui Preserve','Maui','2009-06-05','on bait sponge'),
 ('m0036','KNM','Puu Kukui trail','Puu Kukui Preserve','Maui','2009-06-05','on bait sponge'),
 ('m0037','KNM','Puu Kukui trail','Puu Kukui Preserve','Maui','2009-06-05','on Broussaisia'),
 ('m0038','KNM','Puu Kukui trail','Puu Kukui Preserve','Maui','2009-06-05','on bait sponge'),
 ('m0039','KNM','Puu Kukui trail','Puu Kukui Preserve','Maui','2009-06-05','on bait sponge'),
 ('m0040','KNM','Puu Kukui trail','Puu Kukui Preserve','Maui','2009-06-05','on bait sponge'),
 ('m0041','KNM','Puu Kukui trail','Puu Kukui Preserve','Maui','2009-06-06','on bait sponge'),
 ('m0042','KNM','Puu Kukui trail','Puu Kukui Preserve','Maui','2009-06-06','sweeping Freycinetia'),
 ('m0043','KNM','Puu Kukui trail','Puu Kukui Preserve','Maui','2009-06-06','on Melicope litter'),
 ('m0044','KNM','Puu Kukui trail','Puu Kukui Preserve','Maui','2009-06-06','on Melicope'),
 ('m0045','KNM','Puu Kukui trail','Puu Kukui Preserve','Maui','2009-06-06','on Psychotria'),
 ('m0046','KNM','Puu Kukui trail','Puu Kukui Preserve','Maui','2009-06-06','on Clermontia kakeana'),
 ('m0047','KNM','Olaa trench trail','Puu Makaala','Hawaii','2009-06-12','under leaves'),
 ('m0048','KNM','Puu Pili','Kahua Ranch','Hawaii','2009-06-20','on bait sponge'),
 ('m0049','KNM','Toms Trail kipuka','Upper Waiakea','Hawaii','2009-06-21','sweeping'),
 ('m0050','KNM','Toms Trail kipuka','Upper Waiakea','Hawaii','2009-06-21','on rotten Clermontia'),
 ('m0051','KNM','Toms Trail upper forest','Upper Waiakea','Hawaii','2009-06-21','on bait sponge'),
 ('m0052','KNM','Toms Trail upper forest','Upper Waiakea','Hawaii','2009-06-21','on Pritchardia leaves'),
 ('m0053','KNM','Nualolo Trail','Kuia','Kauai','2009-06-22','sweeping Corynocarpus lvs.'),
 ('m0054','KNM','Nualolo Trail','Kuia','Kauai','2009-06-22','beating Kadua'),
 ('m0055','KNM','Nualolo Trail','Kuia','Kauai','2009-06-22',''),
 ('m0056','KNM','Pihea Trail','Na Pali-Kona','Kauai','2009-06-22','on bait sponge'),
 ('m0057','KNM','Pihea Trail','Na Pali-Kona','Kauai','2009-06-22','under leaves'),
 ('m0058','KNM','Pihea Trail','Na Pali-Kona','Kauai','2009-06-22','on Clermontia'),
 ('m0059','KNM','Paaiki Valley','Kuia','Kauai','2009-06-23','sweeping'),
 ('m0060','KNM','Mahanaloaâ€“Kuia Val. jct.','Kuia','Kauai','2009-06-23','sweeping'),
 ('m0061','KNM','Kuia Valley','Kuia','Kauai','2009-06-23','on bait sponge'),
 ('m0062','KNM','Mahanaloaâ€“Kuia Val. jct.','Kuia','Kauai','2009-06-23','on bait sponge'),
 ('m0063','KNM','Mahanaloa Valley excl.','Kuia','Kauai','2009-06-23','on bait sponge'),
 ('m0064','KNM','Paaiki Valley','Kuia','Kauai','2009-06-23','on bait sponge'),
 ('m0065','KNM','Nualolo Trail','Kuia','Kauai','2009-06-23','on bait sponge'),
 ('m0066','KNM','Alakai Swamp Trail','Na Pali-Kona','Kauai','2009-06-24','on bait sponge'),
 ('m0067','KNM','Alakai Swamp Trail','Na Pali-Kona','Kauai','2009-06-24','sweeping'),
 ('m0068','KNM','Nualolo Trail','Kuia','Kauai','2009-06-24','on bait sponge'),
 ('m0069','KNM','Kapapala Canoe Forest','Kapapala','Hawaii','2009-07-02','sweeping'),
 ('m0070','KNM','Kapapala Canoe Forest','Kapapala','Hawaii','2009-07-02','on bait sponge'),
 ('m0071','JEL','Kapapala Canoe Forest','Kapapala','Hawaii','2009-07-02','on bait sponge'),
 ('m0072','KNM','Laupahoehoe, HIPPNET','Laupahoehoe','Hawaii','2009-07-14','on bait sponge'),
 ('m0073','KNM','Laupahoehoe, HIPPNET','Laupahoehoe','Hawaii','2009-07-14','sweeping'),
 ('m0074','KNM','Laupahoehoe, FR side','Hilo','Hawaii','2009-07-14','sweeping'),
 ('m0075','KNM','Stainback Highway','Upper Waiakea','Hawaii','2009-07-21','on bait sponge'),
 ('m0076','KNM','Stainback Highway','Upper Waiakea','Hawaii','2009-07-21','sweeping'),
 ('m0077','KMI','Toms Trail upper forest','Upper Waiakea','Hawaii','2009-07-21','on bait sponge'),
 ('m0078','KMI','Laupahoehoe FR','Laupahoehoe','Hawaii','2009-07-24','on bait sponge'),
 ('m0079','JEL','Laupahoehoe FR','Laupahoehoe','Hawaii','2009-07-24','on bait sponge'),
 ('m0080','KNM','Laupahoehoe FR','Laupahoehoe','Hawaii','2009-07-24','on bait sponge'),
 ('m0081','KNM','Laupahoehoe FR','Laupahoehoe','Hawaii','2009-07-24','sweeping'),
 ('m0082','KNM','Maakua Gulch','Hauula','Oahu','2009-07-31','sweeping Freycinetia'),
 ('m0083','KNM','above Nuuanu Pali lookout','Honolulu Watershed','Oahu','2009-08-02','on bait sponge'),
 ('m0084','KNM','above Nuuanu Pali lookout','Honolulu Watershed','Oahu','2009-08-02','sweeping'),
 ('m0085','KNM','Kilohana exclosure','Puu O Umi','Hawaii','2009-08-03','on bait sponge'),
 ('m0086','KNM','Kilohana exclosure','Puu O Umi','Hawaii','2009-08-03','sweeping'),
 ('m0087','KNM','Kilohana exclosure','Puu O Umi','Hawaii','2009-08-03','on Astelia flowers'),
 ('m0088','KNM','Puu Waawaa','Puu Waawaa','Hawaii','2009-08-04','on bait sponge'),
 ('m0089','KNM','Puu Waawaa','Puu Waawaa','Hawaii','2009-08-04','sweeping'),
 ('m0090','KNM','Puu Waawaa','Puu Waawaa','Hawaii','2009-08-04','on Cheirodendron leaves'),
 ('m0091','KNM','Puu Waawaa','Puu Waawaa','Hawaii','2009-08-04','sweeping Pisonia'),
 ('m0092','KNM','Kukuiopae','South Kona','Hawaii','2009-08-05','on bait sponge'),
 ('m0093','KNM','Kukuiopae','South Kona','Hawaii','2009-08-05','sweeping'),
 ('m0094','KNM','Kukuiopae','South Kona','Hawaii','2009-08-05','on bait sponge'),
 ('m0095','KNM','Kukuiopae','South Kona','Hawaii','2009-08-05','sweeping Freycinetia'),
 ('m0096','KNM','Hionamoa Gulch','Kau','Hawaii','2009-08-06','on bait sponge'),
 ('m0097','KNM','Hionamoa Gulch','Kau','Hawaii','2009-08-06','sweeping'),
 ('m0098','KNM','Hionamoa Gulch','Kau','Hawaii','2009-08-06','sweeping'),
 ('m0099','KNM','Hionamoa Gulch','Kau','Hawaii','2009-08-06','on bait sponge'),
 ('m0100','KNM','Manuka, olopua kipuka','Manuka','Hawaii','2009-08-07','on bait sponge'),
 ('m0101','KNM','Manuka, olopua kipuka','Manuka','Hawaii','2009-08-07','sweeping'),
 ('m0102','KNM','Kahanaiki Valley','Puu Kukui Preserve','Maui','2009-08-18','on bait sponge'),
 ('m0103','KNM','Kahanaiki Valley','Puu Kukui Preserve','Maui','2009-08-18','in BioLure trap'),
 ('m0104','KNM','Kahanaiki Valley','Puu Kukui Preserve','Maui','2009-08-18','sweeping'),
 ('m0105','KNM','Kahanaiki Valley','Puu Kukui Preserve','Maui','2009-08-18','under leaves'),
 ('m0106','KNM','Kaulalewelewe','Puu Kukui Preserve','Maui','2009-08-18','resting on cabin'),
 ('m0107','KNM','Puu Kukui Trail','Puu Kukui Preserve','Maui','2009-08-18','on bait sponge'),
 ('m0108','KNM','Puu Kukui Trail','Puu Kukui Preserve','Maui','2009-08-18','on Dubautia flowers'),
 ('m0109','KNM','Puu Kukui Trail','Puu Kukui Preserve','Maui','2009-08-18','under leaves'),
 ('m0110','KNM','Puu Kukui Trail','Puu Kukui Preserve','Maui','2009-08-18','in copula'),
 ('m0111','KNM','Puu Kukui Trail','Puu Kukui Preserve','Maui','2009-08-18','in copula in flight'),
 ('m0112','KNM','Waikamoi, Haiku Uka','Haiku Uka','Maui','2009-08-19','on bait sponge'),
 ('m0113','KNM','Waikamoi, Haiku Uka','Haiku Uka','Maui','2009-08-19','sweeping'),
 ('m0114','KNM','Waikamoi, Haiku Uka','Haiku Uka','Maui','2009-08-19','under leaves'),
 ('m0115','KNM','Waikamoi, Haiku Uka','Haiku Uka','Maui','2009-08-19','on Cyrt. platyphylla'),
 ('m0116','KNM','Waikamoi, Haiku Uka','Haiku Uka','Maui','2009-08-20','on bait sponge'),
 ('m0117','KNM','Waikamoi, Haiku Uka','Haiku Uka','Maui','2009-08-20','sweeping'),
 ('m0118','KNM','Powerline Road','Upper Waiakea','Hawaii','2009-08-23','resting in debris'),
 ('m0119','KNM','Powerline Road kipukas','Upper Waiakea','Hawaii','2009-08-23','sweeping'),
 ('m0120','KNM','','','Hawaii','0000-00-00',''),
 ('test','[PH','[PH','[PH','[PH','0000-00-00','[PH');
/*!40000 ALTER TABLE `event` ENABLE KEYS */;


--
-- Definition of table `event_collector`
--

DROP TABLE IF EXISTS `event_collector`;
CREATE TABLE `event_collector` (
  `event_code` char(9) NOT NULL,
  `abbr3_collector` char(3) NOT NULL,
  PRIMARY KEY (`event_code`,`abbr3_collector`),
  KEY `event_collector_FKIndex1` (`event_code`),
  KEY `event_collector_FKIndex2` (`abbr3_collector`),
  CONSTRAINT `event_collector_ibfk_1` FOREIGN KEY (`event_code`) REFERENCES `event` (`event_code`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `event_collector_ibfk_2` FOREIGN KEY (`abbr3_collector`) REFERENCES `collector` (`abbr3_collector`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event_collector`
--

/*!40000 ALTER TABLE `event_collector` DISABLE KEYS */;
/*!40000 ALTER TABLE `event_collector` ENABLE KEYS */;


--
-- Definition of table `island`
--

DROP TABLE IF EXISTS `island`;
CREATE TABLE `island` (
  `island_name` char(10) NOT NULL,
  PRIMARY KEY (`island_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `island`
--

/*!40000 ALTER TABLE `island` DISABLE KEYS */;
INSERT INTO `island` (`island_name`) VALUES 
 (''),
 ('Hawaii'),
 ('Kauai'),
 ('M\n'),
 ('Maui'),
 ('Oahu'),
 ('[PH'),
 ('[PH]');
/*!40000 ALTER TABLE `island` ENABLE KEYS */;


--
-- Definition of table `life`
--

DROP TABLE IF EXISTS `life`;
CREATE TABLE `life` (
  `short_scientific_name` char(9) NOT NULL,
  `scientific_name` varchar(50) NOT NULL,
  PRIMARY KEY (`short_scientific_name`),
  UNIQUE KEY `life_Unique1` (`scientific_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `life`
--

/*!40000 ALTER TABLE `life` DISABLE KEYS */;
INSERT INTO `life` (`short_scientific_name`,`scientific_name`) VALUES 
 ('',''),
 ('ChiDip',' Chironomidae Diptera'),
 ('DelHem',' Delphacidae Hemiptera'),
 ('GryOrt',' Gryllidae Orthoptera'),
 ('HemNeu',' Hemerobiidae Neuroptera'),
 ('MirHem',' Miridae Hemiptera'),
 ('NitCol',' Nitidulidae Coleoptera'),
 ('PsyHem',' Psyllidae Hemiptera'),
 ('ArcDolDip','Arciellia Dolichopodidae Diptera'),
 ('AstAstDip','Asteia Asteiidae Diptera'),
 ('BlaCarCol','Blackburnia Carabidae Coleoptera'),
 ('CamDolDip','Campsicnemus Dolichopodidae Diptera'),
 ('CamDroDip','Campsicnemus Drosophilidae Diptera'),
 ('CepPipDip','Cephalops Pipunculidae Diptera'),
 ('DeiCraHym','Deinomimesa Crabronidae Hymenoptera'),
 ('DicLimDip','Dicranomyia Limoniidae Diptera'),
 ('DroDroDip','Drosophila Drosophilidae Diptera'),
 ('EurDolDip','Eurynogaster Dolichopodidae Diptera'),
 ('EurDroDip','Eurynogaster Drosophilidae Diptera'),
 ('HylColHym','Hylaeus Colletidae Hymenoptera'),
 ('LibDolDip','Libnotes Dolichopodidae Diptera'),
 ('LisMusDip','Lispocephala Muscidae Diptera'),
 ('MecCarCol','Mecyclothorax Carabidae Coleoptera'),
 ('NesLygHem','Neseis Lygaeidae Hemiptera'),
 ('NesMirHem','Nesiomiris Miridae Hemiptera'),
 ('NesVesHym','Nesodynerus Vespidae Hymenoptera'),
 ('NesCicHem','Nesophrosyne Cicadellidae Hemiptera'),
 ('NesDolDip','Nesophrosyne Dolichopodidae Diptera'),
 ('NesDroDip','Nesophrosyne Drosophilidae Diptera'),
 ('NysLygHem','Nysius Lygaeidae Hemiptera'),
 ('OliCixHem','Oliarus Cixiidae Hemiptera'),
 ('OrtDolDip','Orthotylus Dolichopodidae Diptera'),
 ('OrtMirHem','Orthotylus Miridae Hemiptera'),
 ('PlaCerCol','Plagithmysus Cerambycidae Coleoptera'),
 ('ProAglCol','Proterhinus Aglycyderidae Coleoptera'),
 ('S. DroDip','S. (Alloscaptomyza) Drosophilidae Diptera'),
 ('SarMirHem','Sarona Miridae Hemiptera'),
 ('SieBetHym','Sierola Bethylidae Hymenoptera'),
 ('SpoIchHym','Spolas Ichneumonidae Hymenoptera'),
 ('[PH','[PH'),
 ('[PH]','[PH]');
/*!40000 ALTER TABLE `life` ENABLE KEYS */;


--
-- Definition of table `life_media`
--

DROP TABLE IF EXISTS `life_media`;
CREATE TABLE `life_media` (
  `short_scientific_name` char(9) NOT NULL,
  `media_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`short_scientific_name`,`media_id`),
  KEY `life_media_FKIndex1` (`short_scientific_name`),
  KEY `life_media_FKIndex2` (`media_id`),
  CONSTRAINT `life_media_ibfk_1` FOREIGN KEY (`short_scientific_name`) REFERENCES `life` (`short_scientific_name`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `life_media_ibfk_2` FOREIGN KEY (`media_id`) REFERENCES `media` (`media_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `life_media`
--

/*!40000 ALTER TABLE `life_media` DISABLE KEYS */;
/*!40000 ALTER TABLE `life_media` ENABLE KEYS */;


--
-- Definition of table `life_taxonomy`
--

DROP TABLE IF EXISTS `life_taxonomy`;
CREATE TABLE `life_taxonomy` (
  `rank_type` char(25) NOT NULL,
  `rank_name` char(15) NOT NULL,
  `short_scientific_name` char(9) NOT NULL,
  PRIMARY KEY (`rank_type`,`rank_name`,`short_scientific_name`),
  KEY `life_taxonomy_FKIndex2` (`rank_type`,`rank_name`),
  KEY `life_taxonomy_FKIndex1` (`short_scientific_name`),
  CONSTRAINT `life_taxonomy_ibfk_1` FOREIGN KEY (`rank_type`, `rank_name`) REFERENCES `taxonomy_rank` (`rank_type`, `rank_name`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `life_taxonomy_ibfk_2` FOREIGN KEY (`short_scientific_name`) REFERENCES `life` (`short_scientific_name`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `life_taxonomy`
--

/*!40000 ALTER TABLE `life_taxonomy` DISABLE KEYS */;
/*!40000 ALTER TABLE `life_taxonomy` ENABLE KEYS */;


--
-- Definition of table `locality`
--

DROP TABLE IF EXISTS `locality`;
CREATE TABLE `locality` (
  `locality_name` varchar(100) NOT NULL,
  PRIMARY KEY (`locality_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `locality`
--

/*!40000 ALTER TABLE `locality` DISABLE KEYS */;
INSERT INTO `locality` (`locality_name`) VALUES 
 (''),
 ('above Nuuanu Pali lookout'),
 ('Alakai Swamp Trail'),
 ('FBS transect 3'),
 ('Hionamoa Gulch'),
 ('Kahana Valley'),
 ('Kahanaiki Valley'),
 ('Kapapala Canoe Forest'),
 ('Kaulalewelewe'),
 ('Kehena, Honokane Nui rim'),
 ('Kehena, Pololu rim'),
 ('Kilohana exclosure'),
 ('Kuia Valley'),
 ('Kukuiopae'),
 ('Laupahoehoe FR'),
 ('Laupahoehoe, FR side'),
 ('Laupahoehoe, HIPPNET'),
 ('Maakua Gulch'),
 ('Mahanaloa Valley excl.'),
 ('Mahanaloaâ€“Kuia Val. jct.'),
 ('Maile Trail'),
 ('Manuka, olopua kipuka'),
 ('Nualolo Trail'),
 ('Olaa trench trail'),
 ('Paaiki Valley'),
 ('Pihea Trail'),
 ('Piinaau Ridge east'),
 ('Powerline Road'),
 ('Powerline Road kipukas'),
 ('Puu Kukui bog'),
 ('Puu Kukui summit'),
 ('Puu Kukui trail'),
 ('Puu Pili'),
 ('Puu Waawaa'),
 ('Stainback Highway'),
 ('Toms Trail kipuka'),
 ('Toms Trail upper forest'),
 ('Waikamoi, Haiku Uka'),
 ('[PH'),
 ('[PH]');
/*!40000 ALTER TABLE `locality` ENABLE KEYS */;


--
-- Definition of table `location`
--

DROP TABLE IF EXISTS `location`;
CREATE TABLE `location` (
  `island_name` char(10) NOT NULL,
  `reserve_name` char(20) NOT NULL,
  `locality_name` varchar(100) NOT NULL,
  `location_detail_code` int(10) unsigned NOT NULL,
  PRIMARY KEY (`island_name`,`reserve_name`,`locality_name`),
  KEY `Location_FKIndex1` (`island_name`),
  KEY `Location_FKIndex2` (`reserve_name`),
  KEY `Location_FKIndex3` (`locality_name`),
  KEY `Location_FKIndex4` (`location_detail_code`),
  CONSTRAINT `location_ibfk_1` FOREIGN KEY (`island_name`) REFERENCES `island` (`island_name`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `location_ibfk_2` FOREIGN KEY (`reserve_name`) REFERENCES `reserve` (`reserve_name`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `location_ibfk_3` FOREIGN KEY (`locality_name`) REFERENCES `locality` (`locality_name`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `location_ibfk_4` FOREIGN KEY (`location_detail_code`) REFERENCES `location_details` (`location_detail_code`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `location`
--

/*!40000 ALTER TABLE `location` DISABLE KEYS */;
INSERT INTO `location` (`island_name`,`reserve_name`,`locality_name`,`location_detail_code`) VALUES 
 ('Hawaii','Ponoholo Ranch','Kehena, Honokane Nui rim',1),
 ('M\n','Puu Kukui (PK)\n','',1),
 ('[PH','[PH','[PH',1),
 ('Hawaii','Ponoholo Ranch','Kehena, Pololu rim',2),
 ('Hawaii','Puu O Umi','Kilohana exclosure',3),
 ('Maui','Waikamoi','Maile Trail',4),
 ('Maui','Waikamoi','Piinaau Ridge east',5),
 ('Maui','Waikamoi','FBS transect 3',6),
 ('Maui','Puu Kukui Preserve','Kahana Valley',7),
 ('Maui','Puu Kukui Preserve','Puu Kukui trail',8),
 ('Maui','Puu Kukui Preserve','Puu Kukui bog',9),
 ('Maui','Puu Kukui Preserve','Puu Kukui summit',10),
 ('Hawaii','Puu Makaala','Olaa trench trail',11),
 ('Hawaii','Kahua Ranch','Puu Pili',12),
 ('Hawaii','Upper Waiakea','Toms Trail kipuka',13),
 ('Hawaii','Upper Waiakea','Toms Trail upper forest',14),
 ('Kauai','Kuia','Nualolo Trail',15),
 ('Kauai','Na Pali-Kona','Pihea Trail',16),
 ('Kauai','Kuia','Paaiki Valley',17),
 ('Kauai','Kuia','Mahanaloaâ€“Kuia Val. jct.',18),
 ('Kauai','Kuia','Kuia Valley',19),
 ('Kauai','Kuia','Mahanaloa Valley excl.',20),
 ('Kauai','Na Pali-Kona','Alakai Swamp Trail',21),
 ('Hawaii','Kapapala','Kapapala Canoe Forest',22),
 ('Hawaii','Laupahoehoe','Laupahoehoe, HIPPNET',23),
 ('Hawaii','Hilo','Laupahoehoe, FR side',24),
 ('Hawaii','Upper Waiakea','Stainback Highway',25),
 ('Hawaii','Laupahoehoe','Laupahoehoe FR',26),
 ('Oahu','Hauula','Maakua Gulch',27),
 ('Oahu','Honolulu Watershed','above Nuuanu Pali lookout',28),
 ('Hawaii','Puu Waawaa','Puu Waawaa',29),
 ('Hawaii','South Kona','Kukuiopae',30),
 ('Hawaii','Kau','Hionamoa Gulch',31),
 ('Hawaii','Manuka','Manuka, olopua kipuka',32),
 ('Maui','Puu Kukui Preserve','Kahanaiki Valley',33),
 ('Maui','Puu Kukui Preserve','Kaulalewelewe',34),
 ('Maui','Haiku Uka','Waikamoi, Haiku Uka',35),
 ('Hawaii','Upper Waiakea','Powerline Road',36),
 ('Hawaii','Upper Waiakea','Powerline Road kipukas',37),
 ('Hawaii','','',38);
/*!40000 ALTER TABLE `location` ENABLE KEYS */;


--
-- Definition of table `location_details`
--

DROP TABLE IF EXISTS `location_details`;
CREATE TABLE `location_details` (
  `location_detail_code` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `north_degree` decimal(12,0) NOT NULL,
  `west_degree` decimal(12,0) NOT NULL,
  `elevation_foot` decimal(10,0) DEFAULT NULL,
  `waypoint` varchar(25) DEFAULT NULL,
  `utm_zone` int(10) unsigned DEFAULT NULL,
  `utm_band` char(1) DEFAULT NULL,
  `utm_northing` int(7) unsigned DEFAULT NULL,
  `utm_easting` int(7) unsigned NOT NULL,
  PRIMARY KEY (`location_detail_code`),
  KEY `longitude` (`north_degree`),
  KEY `latitude` (`west_degree`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `location_details`
--

/*!40000 ALTER TABLE `location_details` DISABLE KEYS */;
INSERT INTO `location_details` (`location_detail_code`,`north_degree`,`west_degree`,`elevation_foot`,`waypoint`,`utm_zone`,`utm_band`,`utm_northing`,`utm_easting`) VALUES 
 (1,'20','156','3000','',5,'Q',2229848,213467),
 (2,'20','156','2900','',5,'Q',2230271,213220),
 (3,'20','156','4700','',5,'Q',2223711,213676),
 (4,'21','156','4600','',4,'Q',2302677,785778),
 (5,'21','156','5800','',4,'Q',2299938,790169),
 (6,'21','156','5550','',4,'Q',2301040,788786),
 (7,'21','157','1650','',4,'Q',2318119,747358),
 (8,'21','157','3400','',4,'Q',2315752,749091),
 (9,'21','157','4800','',4,'Q',2313817,750440),
 (10,'21','157','5790','',4,'Q',2311914,751081),
 (11,'20','155','3700','',5,'Q',2160885,265792),
 (12,'20','156','4300','',0,'',0,0),
 (13,'20','155','3200','',5,'Q',2166032,267467),
 (14,'20','155','3200','',5,'Q',2165713,267663),
 (15,'22','160','3500','',0,'',0,0),
 (16,'22','160','4100','',4,'Q',2450025,436304),
 (17,'22','160','2150','',0,'',0,0),
 (18,'22','160','1900','',4,'Q',2448193,427691),
 (19,'22','160','1800','',4,'Q',2448422,427482),
 (20,'22','160','2200','',4,'Q',2447943,427771),
 (21,'22','160','3900','',4,'Q',2449167,436252),
 (22,'19','155','4000','',5,'Q',2140344,241556),
 (23,'20','155','3800','',5,'Q',2205410,260388),
 (24,'20','155','3800','',5,'Q',2205545,260213),
 (25,'20','155','3600','',5,'Q',2165732,265528),
 (26,'20','155','3800','',5,'Q',2205545,260213),
 (27,'22','158','600','',0,'',0,0),
 (28,'21','158','1400','',4,'Q',2363022,625313),
 (29,'20','156','4950','',5,'Q',2184371,196617),
 (30,'19','156','3750','',5,'Q',2136945,202243),
 (31,'19','156','3250','',5,'Q',2128711,234842),
 (32,'19','156','2300','',5,'Q',2116249,204050),
 (33,'21','157','2100','',4,'Q',2317462,747220),
 (34,'21','157','2980','',4,'Q',2316738,747903),
 (35,'21','156','4200','',4,'Q',2303641,786969),
 (36,'20','155','5700','',5,'Q',2174474,251855),
 (37,'20','155','5800','',5,'Q',2172669,251129),
 (38,'0','0','0','',0,'',0,0),
 (39,'0','0','0','[PH]',0,'[',0,0),
 (40,'0','0','0','[PH]',0,'[',0,0),
 (41,'0','0','0','[PH]',0,'[',0,0),
 (42,'0','0','0','[PH]',0,'[',0,0),
 (43,'0','0','0','[PH]',0,'[',0,0),
 (44,'0','0','0','[PH]',0,'[',0,0),
 (45,'0','0','0','[PH]',0,'[',0,0),
 (46,'0','0','0','[PH]',0,'[',0,0),
 (47,'0','0','0','[PH]',0,'[',0,0),
 (48,'0','0','0','[PH]',0,'[',0,0),
 (49,'0','0','0','[PH]',0,'[',0,0),
 (50,'0','0','0','[PH]',0,'[',0,0),
 (51,'0','0','0','[PH]',0,'[',0,0),
 (52,'0','0','0','[PH]',0,'[',0,0),
 (53,'0','0','0','[PH]',0,'[',0,0),
 (54,'0','0','0','[PH]',0,'[',0,0),
 (55,'0','0','0','[PH]',0,'[',0,0),
 (56,'0','0','0','[PH]',0,'[',0,0),
 (57,'0','0','0','[PH]',0,'[',0,0),
 (58,'0','0','0','[PH]',0,'[',0,0),
 (59,'0','0','0','[PH]',0,'[',0,0),
 (60,'0','0','0','[PH]',0,'[',0,0),
 (61,'0','0','0','[PH]',0,'[',0,0),
 (62,'0','0','0','[PH]',0,'[',0,0),
 (63,'0','0','0','',0,'',0,0),
 (64,'0','0','0','',0,'',0,0),
 (65,'0','0','0','',0,'',0,0),
 (66,'0','0','0','',0,'',0,0),
 (67,'0','0','0','',0,'',0,0),
 (68,'0','0','0','',0,'',0,0),
 (69,'0','0','0','[PH',0,'[',0,0),
 (70,'0','0','0','[PH',0,'[',0,0),
 (71,'0','0','0','[PH',0,'[',0,0),
 (72,'0','0','0','[PH',0,'[',0,0),
 (73,'0','0','0','[PH',0,'[',0,0),
 (74,'0','0','0','[PH',0,'[',0,0),
 (75,'0','0','0','[PH',0,'[',0,0),
 (76,'0','0','0','[PH',0,'[',0,0),
 (77,'0','0','0','[PH',0,'[',0,0),
 (78,'0','0','0','[PH',0,'[',0,0),
 (79,'0','0','0','[PH',0,'[',0,0),
 (80,'0','0','0','[PH',0,'[',0,0),
 (81,'0','0','0','[PH',0,'[',0,0),
 (82,'0','0','0','[PH',0,'[',0,0),
 (83,'0','0','0','[PH',0,'[',0,0),
 (84,'0','0','0','[PH',0,'[',0,0),
 (85,'0','0','0','[PH',0,'[',0,0),
 (86,'0','0','0','[PH',0,'[',0,0),
 (87,'0','0','0','[PH',0,'[',0,0),
 (88,'0','0','0','[PH',0,'[',0,0),
 (89,'0','0','0','[PH',0,'[',0,0),
 (90,'0','0','0','[PH',0,'[',0,0),
 (91,'0','0','0','[PH',0,'[',0,0),
 (92,'0','0','0','[PH',0,'[',0,0);
/*!40000 ALTER TABLE `location_details` ENABLE KEYS */;


--
-- Definition of table `media`
--

DROP TABLE IF EXISTS `media`;
CREATE TABLE `media` (
  `media_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `file_format` char(4) NOT NULL,
  `directory_path` varchar(125) NOT NULL,
  `file_name` varchar(125) NOT NULL,
  `media_note` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`media_id`),
  KEY `media_FKIndex1` (`file_format`),
  KEY `media_Unique1` (`directory_path`,`file_name`,`file_format`),
  CONSTRAINT `media_ibfk_1` FOREIGN KEY (`file_format`) REFERENCES `media_type` (`file_format`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `media`
--

/*!40000 ALTER TABLE `media` DISABLE KEYS */;
/*!40000 ALTER TABLE `media` ENABLE KEYS */;


--
-- Definition of table `media_meta`
--

DROP TABLE IF EXISTS `media_meta`;
CREATE TABLE `media_meta` (
  `meta_item` char(10) NOT NULL,
  `media_id` int(10) unsigned NOT NULL,
  `meta_numeric_value` int(10) unsigned NOT NULL,
  PRIMARY KEY (`meta_item`,`media_id`),
  KEY `media_meta_FKIndex1` (`meta_item`),
  KEY `media_meta_FKIndex2` (`media_id`),
  CONSTRAINT `media_meta_ibfk_1` FOREIGN KEY (`media_id`) REFERENCES `media` (`media_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `media_meta_ibfk_2` FOREIGN KEY (`meta_item`) REFERENCES `meta` (`meta_item`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `media_meta`
--

/*!40000 ALTER TABLE `media_meta` DISABLE KEYS */;
/*!40000 ALTER TABLE `media_meta` ENABLE KEYS */;


--
-- Definition of table `media_type`
--

DROP TABLE IF EXISTS `media_type`;
CREATE TABLE `media_type` (
  `file_format` char(4) NOT NULL,
  `media_type_note` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`file_format`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `media_type`
--

/*!40000 ALTER TABLE `media_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `media_type` ENABLE KEYS */;


--
-- Definition of table `meta`
--

DROP TABLE IF EXISTS `meta`;
CREATE TABLE `meta` (
  `meta_item` char(10) NOT NULL,
  PRIMARY KEY (`meta_item`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `meta`
--

/*!40000 ALTER TABLE `meta` DISABLE KEYS */;
/*!40000 ALTER TABLE `meta` ENABLE KEYS */;


--
-- Definition of table `organization`
--

DROP TABLE IF EXISTS `organization`;
CREATE TABLE `organization` (
  `abbr4_organization` char(4) NOT NULL,
  `organization_name` varchar(50) NOT NULL,
  `organization_street` varchar(50) DEFAULT NULL,
  `organization_city` varchar(50) DEFAULT NULL,
  `organization_state` varchar(50) DEFAULT NULL,
  `organization_zip` varchar(10) DEFAULT NULL,
  `organization_note` varchar(255) DEFAULT NULL,
  `organization_country` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`abbr4_organization`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `organization`
--

/*!40000 ALTER TABLE `organization` DISABLE KEYS */;
INSERT INTO `organization` (`abbr4_organization`,`organization_name`,`organization_street`,`organization_city`,`organization_state`,`organization_zip`,`organization_note`,`organization_country`) VALUES 
 ('','','','','','','',''),
 ('test','[PH]','[PH]','[PH]','[PH]','[PH]','[PH]','[PH]'),
 ('UHH','',NULL,NULL,NULL,NULL,NULL,NULL),
 ('[PH','[PH','[PH','[PH','[PH','[PH','[PH','[PH');
/*!40000 ALTER TABLE `organization` ENABLE KEYS */;


--
-- Definition of table `preservation_status`
--

DROP TABLE IF EXISTS `preservation_status`;
CREATE TABLE `preservation_status` (
  `status_code` char(4) NOT NULL,
  `status_description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`status_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `preservation_status`
--

/*!40000 ALTER TABLE `preservation_status` DISABLE KEYS */;
INSERT INTO `preservation_status` (`status_code`,`status_description`) VALUES 
 ('',''),
 ('[PH','[PH'),
 ('[PH]','[PH]');
/*!40000 ALTER TABLE `preservation_status` ENABLE KEYS */;


--
-- Definition of table `rank_type`
--

DROP TABLE IF EXISTS `rank_type`;
CREATE TABLE `rank_type` (
  `rank_type` char(25) NOT NULL,
  PRIMARY KEY (`rank_type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rank_type`
--

/*!40000 ALTER TABLE `rank_type` DISABLE KEYS */;
/*!40000 ALTER TABLE `rank_type` ENABLE KEYS */;


--
-- Definition of table `reserve`
--

DROP TABLE IF EXISTS `reserve`;
CREATE TABLE `reserve` (
  `reserve_name` char(20) NOT NULL,
  `permission_type` char(20) DEFAULT NULL,
  PRIMARY KEY (`reserve_name`),
  KEY `reserve_FKIndex1` (`permission_type`),
  CONSTRAINT `reserve_ibfk_1` FOREIGN KEY (`permission_type`) REFERENCES `reserve_permission` (`permission_type`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reserve`
--

/*!40000 ALTER TABLE `reserve` DISABLE KEYS */;
INSERT INTO `reserve` (`reserve_name`,`permission_type`) VALUES 
 ('',''),
 ('Kahua Ranch',''),
 ('Ponoholo Ranch',''),
 ('Puu Kukui (PK)\n',''),
 ('Kapapala','CMA'),
 ('Haiku Uka','EMI'),
 ('Hauula','FR'),
 ('Hilo','FR'),
 ('Honolulu Watershed','FR'),
 ('Kau','FR'),
 ('Na Pali-Kona','FR'),
 ('South Kona','FR'),
 ('Upper Waiakea','FR'),
 ('Puu Kukui Preserve','MLP'),
 ('Kuia','NAR'),
 ('Laupahoehoe','NAR'),
 ('Manuka','NAR'),
 ('Puu Makaala','NAR'),
 ('Puu O Umi','NAR'),
 ('Waikamoi','TNC'),
 ('Puu Waawaa','WS'),
 ('[PH','[PH'),
 ('[PH]','[PH]');
/*!40000 ALTER TABLE `reserve` ENABLE KEYS */;


--
-- Definition of table `reserve_permission`
--

DROP TABLE IF EXISTS `reserve_permission`;
CREATE TABLE `reserve_permission` (
  `permission_type` char(20) NOT NULL,
  PRIMARY KEY (`permission_type`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reserve_permission`
--

/*!40000 ALTER TABLE `reserve_permission` DISABLE KEYS */;
INSERT INTO `reserve_permission` (`permission_type`) VALUES 
 (''),
 ('CMA'),
 ('EMI'),
 ('FR'),
 ('MLP'),
 ('NAR'),
 ('TNC'),
 ('WS'),
 ('[PH'),
 ('[PH]');
/*!40000 ALTER TABLE `reserve_permission` ENABLE KEYS */;


--
-- Definition of table `sex`
--

DROP TABLE IF EXISTS `sex`;
CREATE TABLE `sex` (
  `sex_code` char(6) NOT NULL,
  `sex_type` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`sex_code`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sex`
--

/*!40000 ALTER TABLE `sex` DISABLE KEYS */;
INSERT INTO `sex` (`sex_code`,`sex_type`) VALUES 
 ('',''),
 ('f',NULL),
 ('m',NULL),
 ('[PH','[PH'),
 ('[PH]','[PH]');
/*!40000 ALTER TABLE `sex` ENABLE KEYS */;


--
-- Definition of table `specimen`
--

DROP TABLE IF EXISTS `specimen`;
CREATE TABLE `specimen` (
  `specimen_code` char(12) NOT NULL,
  `event_code` char(9) NOT NULL,
  `catalog_code` char(9) NOT NULL,
  `cabinet_code` char(5) NOT NULL,
  `box_code` char(9) NOT NULL,
  `section_code` char(9) NOT NULL,
  `abbr4_organization` char(4) NOT NULL,
  `sex_code` char(6) DEFAULT NULL,
  `status_code` char(4) DEFAULT NULL,
  PRIMARY KEY (`specimen_code`),
  KEY `specimen_FKIndex1` (`abbr4_organization`,`cabinet_code`,`box_code`,`section_code`),
  KEY `specimen_FKIndex2` (`status_code`),
  KEY `specimen_FKIndex3` (`sex_code`),
  KEY `specimen_FKIndex4` (`catalog_code`,`event_code`),
  CONSTRAINT `specimen_ibfk_1` FOREIGN KEY (`abbr4_organization`, `cabinet_code`, `box_code`, `section_code`) REFERENCES `container` (`abbr4_organization`, `cabinet_code`, `box_code`, `section_code`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `specimen_ibfk_2` FOREIGN KEY (`status_code`) REFERENCES `preservation_status` (`status_code`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `specimen_ibfk_3` FOREIGN KEY (`sex_code`) REFERENCES `sex` (`sex_code`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `specimen_ibfk_4` FOREIGN KEY (`catalog_code`, `event_code`) REFERENCES `collection` (`catalog_code`, `event_code`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `specimen`
--

/*!40000 ALTER TABLE `specimen` DISABLE KEYS */;
INSERT INTO `specimen` (`specimen_code`,`event_code`,`catalog_code`,`cabinet_code`,`box_code`,`section_code`,`abbr4_organization`,`sex_code`,`status_code`) VALUES 
 ('','m0001','01','[PH]','10','1','UHH','m',NULL),
 ('[PH','test','[PH','[PH','[PH','[PH','[PH','[PH','[PH');
/*!40000 ALTER TABLE `specimen` ENABLE KEYS */;


--
-- Definition of table `specimen_dna`
--

DROP TABLE IF EXISTS `specimen_dna`;
CREATE TABLE `specimen_dna` (
  `extraction_code` char(9) NOT NULL,
  `specimen_code` char(12) NOT NULL,
  PRIMARY KEY (`extraction_code`,`specimen_code`),
  KEY `specimen_dna_FKIndex1` (`specimen_code`),
  KEY `specimen_dna_FKIndex2` (`extraction_code`),
  CONSTRAINT `specimen_dna_ibfk_1` FOREIGN KEY (`specimen_code`) REFERENCES `specimen` (`specimen_code`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `specimen_dna_ibfk_2` FOREIGN KEY (`extraction_code`) REFERENCES `dna` (`extraction_code`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `specimen_dna`
--

/*!40000 ALTER TABLE `specimen_dna` DISABLE KEYS */;
/*!40000 ALTER TABLE `specimen_dna` ENABLE KEYS */;


--
-- Definition of table `specimen_location_code`
--

DROP TABLE IF EXISTS `specimen_location_code`;
CREATE TABLE `specimen_location_code` (
  `specimen_code` char(12) NOT NULL,
  `location_detail_code` int(10) unsigned NOT NULL,
  PRIMARY KEY (`specimen_code`),
  KEY `specimen_location_code_FKIndex1` (`specimen_code`),
  KEY `specimen_location_code_FKIndex2` (`location_detail_code`),
  CONSTRAINT `specimen_location_code_ibfk_1` FOREIGN KEY (`specimen_code`) REFERENCES `specimen` (`specimen_code`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `specimen_location_code_ibfk_2` FOREIGN KEY (`location_detail_code`) REFERENCES `location_details` (`location_detail_code`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `specimen_location_code`
--

/*!40000 ALTER TABLE `specimen_location_code` DISABLE KEYS */;
/*!40000 ALTER TABLE `specimen_location_code` ENABLE KEYS */;


--
-- Definition of table `specimen_media`
--

DROP TABLE IF EXISTS `specimen_media`;
CREATE TABLE `specimen_media` (
  `media_id` int(10) unsigned NOT NULL,
  `specimen_code` char(12) NOT NULL,
  PRIMARY KEY (`media_id`,`specimen_code`),
  KEY `specimen_media_FKIndex1` (`specimen_code`),
  KEY `specimen_media_FKIndex2` (`media_id`),
  CONSTRAINT `specimen_media_ibfk_1` FOREIGN KEY (`specimen_code`) REFERENCES `specimen` (`specimen_code`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `specimen_media_ibfk_2` FOREIGN KEY (`media_id`) REFERENCES `media` (`media_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `specimen_media`
--

/*!40000 ALTER TABLE `specimen_media` DISABLE KEYS */;
/*!40000 ALTER TABLE `specimen_media` ENABLE KEYS */;


--
-- Definition of table `taxonomy`
--

DROP TABLE IF EXISTS `taxonomy`;
CREATE TABLE `taxonomy` (
  `rank_name` char(15) NOT NULL,
  `rank_name_2` char(15) NOT NULL,
  `mandatory` enum('yes','no') NOT NULL,
  PRIMARY KEY (`rank_name`),
  KEY `taxonomy_FKIndex1` (`rank_name_2`),
  CONSTRAINT `taxonomy_ibfk_1` FOREIGN KEY (`rank_name_2`) REFERENCES `taxonomy` (`rank_name`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `taxonomy`
--

/*!40000 ALTER TABLE `taxonomy` DISABLE KEYS */;
/*!40000 ALTER TABLE `taxonomy` ENABLE KEYS */;


--
-- Definition of table `taxonomy_rank`
--

DROP TABLE IF EXISTS `taxonomy_rank`;
CREATE TABLE `taxonomy_rank` (
  `rank_name` char(15) NOT NULL,
  `rank_type` char(25) NOT NULL,
  PRIMARY KEY (`rank_name`,`rank_type`),
  KEY `taxonomy_rank_FKIndex1` (`rank_type`),
  KEY `taxonomy_rank_FKIndex2` (`rank_name`),
  CONSTRAINT `taxonomy_rank_ibfk_1` FOREIGN KEY (`rank_name`) REFERENCES `taxonomy` (`rank_name`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `taxonomy_rank_ibfk_2` FOREIGN KEY (`rank_type`) REFERENCES `rank_type` (`rank_type`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `taxonomy_rank`
--

/*!40000 ALTER TABLE `taxonomy_rank` DISABLE KEYS */;
/*!40000 ALTER TABLE `taxonomy_rank` ENABLE KEYS */;


--
-- Definition of table `upload_column_names`
--

DROP TABLE IF EXISTS `upload_column_names`;
CREATE TABLE `upload_column_names` (
  `abbr3_collector` char(3) NOT NULL,
  `xml_name` varchar(50) NOT NULL,
  `attribute_name` varchar(50) DEFAULT NULL,
  `name_type` enum('taxon','column') DEFAULT NULL,
  PRIMARY KEY (`abbr3_collector`,`xml_name`),
  KEY `upload_column_names_FKIndex1` (`abbr3_collector`),
  CONSTRAINT `upload_column_names_ibfk_1` FOREIGN KEY (`abbr3_collector`) REFERENCES `collector` (`abbr3_collector`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `upload_column_names`
--

/*!40000 ALTER TABLE `upload_column_names` DISABLE KEYS */;
/*!40000 ALTER TABLE `upload_column_names` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
